// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int abc_action_bar_content_inset_material = 0x7f07000b;
    public static final int abc_action_bar_default_height_material = 0x7f070001;
    public static final int abc_action_bar_default_padding_end_material = 0x7f07000c;
    public static final int abc_action_bar_default_padding_start_material = 0x7f07000d;
    public static final int abc_action_bar_icon_vertical_padding_material = 0x7f070010;
    public static final int abc_action_bar_overflow_padding_end_material = 0x7f070011;
    public static final int abc_action_bar_overflow_padding_start_material = 0x7f070012;
    public static final int abc_action_bar_progress_bar_size = 0x7f070002;
    public static final int abc_action_bar_stacked_max_height = 0x7f070013;
    public static final int abc_action_bar_stacked_tab_max_width = 0x7f070014;
    public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f070015;
    public static final int abc_action_bar_subtitle_top_margin_material = 0x7f070016;
    public static final int abc_action_button_min_height_material = 0x7f070017;
    public static final int abc_action_button_min_width_material = 0x7f070018;
    public static final int abc_action_button_min_width_overflow_material = 0x7f070019;
    public static final int abc_alert_dialog_button_bar_height = 0x7f070000;
    public static final int abc_button_inset_horizontal_material = 0x7f07001a;
    public static final int abc_button_inset_vertical_material = 0x7f07001b;
    public static final int abc_button_padding_horizontal_material = 0x7f07001c;
    public static final int abc_button_padding_vertical_material = 0x7f07001d;
    public static final int abc_config_prefDialogWidth = 0x7f070005;
    public static final int abc_control_corner_material = 0x7f07001e;
    public static final int abc_control_inset_material = 0x7f07001f;
    public static final int abc_control_padding_material = 0x7f070020;
    public static final int abc_dialog_list_padding_vertical_material = 0x7f070021;
    public static final int abc_dialog_min_width_major = 0x7f070022;
    public static final int abc_dialog_min_width_minor = 0x7f070023;
    public static final int abc_dialog_padding_material = 0x7f070024;
    public static final int abc_dialog_padding_top_material = 0x7f070025;
    public static final int abc_disabled_alpha_material_dark = 0x7f070026;
    public static final int abc_disabled_alpha_material_light = 0x7f070027;
    public static final int abc_dropdownitem_icon_width = 0x7f070028;
    public static final int abc_dropdownitem_text_padding_left = 0x7f070029;
    public static final int abc_dropdownitem_text_padding_right = 0x7f07002a;
    public static final int abc_edit_text_inset_bottom_material = 0x7f07002b;
    public static final int abc_edit_text_inset_horizontal_material = 0x7f07002c;
    public static final int abc_edit_text_inset_top_material = 0x7f07002d;
    public static final int abc_floating_window_z = 0x7f07002e;
    public static final int abc_list_item_padding_horizontal_material = 0x7f07002f;
    public static final int abc_panel_menu_list_width = 0x7f070030;
    public static final int abc_search_view_preferred_width = 0x7f070031;
    public static final int abc_search_view_text_min_width = 0x7f070006;
    public static final int abc_switch_padding = 0x7f07000e;
    public static final int abc_text_size_body_1_material = 0x7f070032;
    public static final int abc_text_size_body_2_material = 0x7f070033;
    public static final int abc_text_size_button_material = 0x7f070034;
    public static final int abc_text_size_caption_material = 0x7f070035;
    public static final int abc_text_size_display_1_material = 0x7f070036;
    public static final int abc_text_size_display_2_material = 0x7f070037;
    public static final int abc_text_size_display_3_material = 0x7f070038;
    public static final int abc_text_size_display_4_material = 0x7f070039;
    public static final int abc_text_size_headline_material = 0x7f07003a;
    public static final int abc_text_size_large_material = 0x7f07003b;
    public static final int abc_text_size_medium_material = 0x7f07003c;
    public static final int abc_text_size_menu_material = 0x7f07003d;
    public static final int abc_text_size_small_material = 0x7f07003e;
    public static final int abc_text_size_subhead_material = 0x7f07003f;
    public static final int abc_text_size_subtitle_material_toolbar = 0x7f070003;
    public static final int abc_text_size_title_material = 0x7f070040;
    public static final int abc_text_size_title_material_toolbar = 0x7f070004;
    public static final int activity_horizontal_margin = 0x7f07000f;
    public static final int activity_vertical_margin = 0x7f070041;
    public static final int dialog_fixed_height_major = 0x7f070007;
    public static final int dialog_fixed_height_minor = 0x7f070008;
    public static final int dialog_fixed_width_major = 0x7f070009;
    public static final int dialog_fixed_width_minor = 0x7f07000a;
    public static final int disabled_alpha_material_dark = 0x7f070042;
    public static final int disabled_alpha_material_light = 0x7f070043;
    public static final int highlight_alpha_material_colored = 0x7f070044;
    public static final int highlight_alpha_material_dark = 0x7f070045;
    public static final int highlight_alpha_material_light = 0x7f070046;
    public static final int notification_large_icon_height = 0x7f070047;
    public static final int notification_large_icon_width = 0x7f070048;
    public static final int notification_subtext_size = 0x7f070049;

    public ()
    {
    }
}
