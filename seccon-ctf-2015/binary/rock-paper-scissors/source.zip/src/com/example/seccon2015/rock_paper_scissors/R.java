// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


public final class R
{
    public static final class anim
    {

        public static final int abc_fade_in = 0x7f050000;
        public static final int abc_fade_out = 0x7f050001;
        public static final int abc_grow_fade_in_from_bottom = 0x7f050002;
        public static final int abc_popup_enter = 0x7f050003;
        public static final int abc_popup_exit = 0x7f050004;
        public static final int abc_shrink_fade_out_from_bottom = 0x7f050005;
        public static final int abc_slide_in_bottom = 0x7f050006;
        public static final int abc_slide_in_top = 0x7f050007;
        public static final int abc_slide_out_bottom = 0x7f050008;
        public static final int abc_slide_out_top = 0x7f050009;

        public anim()
        {
        }
    }

    public static final class attr
    {

        public static final int actionBarDivider = 0x7f010062;
        public static final int actionBarItemBackground = 0x7f010063;
        public static final int actionBarPopupTheme = 0x7f01005c;
        public static final int actionBarSize = 0x7f010061;
        public static final int actionBarSplitStyle = 0x7f01005e;
        public static final int actionBarStyle = 0x7f01005d;
        public static final int actionBarTabBarStyle = 0x7f010058;
        public static final int actionBarTabStyle = 0x7f010057;
        public static final int actionBarTabTextStyle = 0x7f010059;
        public static final int actionBarTheme = 0x7f01005f;
        public static final int actionBarWidgetTheme = 0x7f010060;
        public static final int actionButtonStyle = 0x7f01007c;
        public static final int actionDropDownStyle = 0x7f010078;
        public static final int actionLayout = 0x7f010033;
        public static final int actionMenuTextAppearance = 0x7f010064;
        public static final int actionMenuTextColor = 0x7f010065;
        public static final int actionModeBackground = 0x7f010068;
        public static final int actionModeCloseButtonStyle = 0x7f010067;
        public static final int actionModeCloseDrawable = 0x7f01006a;
        public static final int actionModeCopyDrawable = 0x7f01006c;
        public static final int actionModeCutDrawable = 0x7f01006b;
        public static final int actionModeFindDrawable = 0x7f010070;
        public static final int actionModePasteDrawable = 0x7f01006d;
        public static final int actionModePopupWindowStyle = 0x7f010072;
        public static final int actionModeSelectAllDrawable = 0x7f01006e;
        public static final int actionModeShareDrawable = 0x7f01006f;
        public static final int actionModeSplitBackground = 0x7f010069;
        public static final int actionModeStyle = 0x7f010066;
        public static final int actionModeWebSearchDrawable = 0x7f010071;
        public static final int actionOverflowButtonStyle = 0x7f01005a;
        public static final int actionOverflowMenuStyle = 0x7f01005b;
        public static final int actionProviderClass = 0x7f010035;
        public static final int actionViewClass = 0x7f010034;
        public static final int activityChooserViewStyle = 0x7f010084;
        public static final int alertDialogButtonGroupStyle = 0x7f0100a6;
        public static final int alertDialogCenterButtons = 0x7f0100a7;
        public static final int alertDialogStyle = 0x7f0100a5;
        public static final int alertDialogTheme = 0x7f0100a8;
        public static final int arrowHeadLength = 0x7f01002b;
        public static final int arrowShaftLength = 0x7f01002c;
        public static final int autoCompleteTextViewStyle = 0x7f0100ad;
        public static final int background = 0x7f01000c;
        public static final int backgroundSplit = 0x7f01000e;
        public static final int backgroundStacked = 0x7f01000d;
        public static final int backgroundTint = 0x7f0100c9;
        public static final int backgroundTintMode = 0x7f0100ca;
        public static final int barLength = 0x7f01002d;
        public static final int borderlessButtonStyle = 0x7f010081;
        public static final int buttonBarButtonStyle = 0x7f01007e;
        public static final int buttonBarNegativeButtonStyle = 0x7f0100ab;
        public static final int buttonBarNeutralButtonStyle = 0x7f0100ac;
        public static final int buttonBarPositiveButtonStyle = 0x7f0100aa;
        public static final int buttonBarStyle = 0x7f01007d;
        public static final int buttonPanelSideLayout = 0x7f01001f;
        public static final int buttonStyle = 0x7f0100ae;
        public static final int buttonStyleSmall = 0x7f0100af;
        public static final int buttonTint = 0x7f010025;
        public static final int buttonTintMode = 0x7f010026;
        public static final int checkboxStyle = 0x7f0100b0;
        public static final int checkedTextViewStyle = 0x7f0100b1;
        public static final int closeIcon = 0x7f01003d;
        public static final int closeItemLayout = 0x7f01001c;
        public static final int collapseContentDescription = 0x7f0100c0;
        public static final int collapseIcon = 0x7f0100bf;
        public static final int color = 0x7f010027;
        public static final int colorAccent = 0x7f01009e;
        public static final int colorButtonNormal = 0x7f0100a2;
        public static final int colorControlActivated = 0x7f0100a0;
        public static final int colorControlHighlight = 0x7f0100a1;
        public static final int colorControlNormal = 0x7f01009f;
        public static final int colorPrimary = 0x7f01009c;
        public static final int colorPrimaryDark = 0x7f01009d;
        public static final int colorSwitchThumbNormal = 0x7f0100a3;
        public static final int commitIcon = 0x7f010042;
        public static final int contentInsetEnd = 0x7f010017;
        public static final int contentInsetLeft = 0x7f010018;
        public static final int contentInsetRight = 0x7f010019;
        public static final int contentInsetStart = 0x7f010016;
        public static final int controlBackground = 0x7f0100a4;
        public static final int customNavigationLayout = 0x7f01000f;
        public static final int defaultQueryHint = 0x7f01003c;
        public static final int dialogPreferredPadding = 0x7f010076;
        public static final int dialogTheme = 0x7f010075;
        public static final int displayOptions = 0x7f010005;
        public static final int divider = 0x7f01000b;
        public static final int dividerHorizontal = 0x7f010083;
        public static final int dividerPadding = 0x7f010031;
        public static final int dividerVertical = 0x7f010082;
        public static final int drawableSize = 0x7f010029;
        public static final int drawerArrowStyle = 0x7f010000;
        public static final int dropDownListViewStyle = 0x7f010094;
        public static final int dropdownListPreferredItemHeight = 0x7f010079;
        public static final int editTextBackground = 0x7f01008a;
        public static final int editTextColor = 0x7f010089;
        public static final int editTextStyle = 0x7f0100b2;
        public static final int elevation = 0x7f01001a;
        public static final int expandActivityOverflowButtonDrawable = 0x7f01001e;
        public static final int gapBetweenBars = 0x7f01002a;
        public static final int goIcon = 0x7f01003e;
        public static final int height = 0x7f010001;
        public static final int hideOnContentScroll = 0x7f010015;
        public static final int homeAsUpIndicator = 0x7f01007b;
        public static final int homeLayout = 0x7f010010;
        public static final int icon = 0x7f010009;
        public static final int iconifiedByDefault = 0x7f01003a;
        public static final int indeterminateProgressStyle = 0x7f010012;
        public static final int initialActivityCount = 0x7f01001d;
        public static final int isLightTheme = 0x7f010002;
        public static final int itemPadding = 0x7f010014;
        public static final int layout = 0x7f010039;
        public static final int listChoiceBackgroundIndicator = 0x7f01009b;
        public static final int listDividerAlertDialog = 0x7f010077;
        public static final int listItemLayout = 0x7f010023;
        public static final int listLayout = 0x7f010020;
        public static final int listPopupWindowStyle = 0x7f010095;
        public static final int listPreferredItemHeight = 0x7f01008f;
        public static final int listPreferredItemHeightLarge = 0x7f010091;
        public static final int listPreferredItemHeightSmall = 0x7f010090;
        public static final int listPreferredItemPaddingLeft = 0x7f010092;
        public static final int listPreferredItemPaddingRight = 0x7f010093;
        public static final int logo = 0x7f01000a;
        public static final int logoDescription = 0x7f0100c3;
        public static final int maxButtonHeight = 0x7f0100be;
        public static final int measureWithLargestChild = 0x7f01002f;
        public static final int multiChoiceItemLayout = 0x7f010021;
        public static final int navigationContentDescription = 0x7f0100c2;
        public static final int navigationIcon = 0x7f0100c1;
        public static final int navigationMode = 0x7f010004;
        public static final int overlapAnchor = 0x7f010037;
        public static final int paddingEnd = 0x7f0100c7;
        public static final int paddingStart = 0x7f0100c6;
        public static final int panelBackground = 0x7f010098;
        public static final int panelMenuListTheme = 0x7f01009a;
        public static final int panelMenuListWidth = 0x7f010099;
        public static final int popupMenuStyle = 0x7f010087;
        public static final int popupTheme = 0x7f01001b;
        public static final int popupWindowStyle = 0x7f010088;
        public static final int preserveIconSpacing = 0x7f010036;
        public static final int progressBarPadding = 0x7f010013;
        public static final int progressBarStyle = 0x7f010011;
        public static final int queryBackground = 0x7f010044;
        public static final int queryHint = 0x7f01003b;
        public static final int radioButtonStyle = 0x7f0100b3;
        public static final int ratingBarStyle = 0x7f0100b4;
        public static final int searchHintIcon = 0x7f010040;
        public static final int searchIcon = 0x7f01003f;
        public static final int searchViewStyle = 0x7f01008e;
        public static final int selectableItemBackground = 0x7f01007f;
        public static final int selectableItemBackgroundBorderless = 0x7f010080;
        public static final int showAsAction = 0x7f010032;
        public static final int showDividers = 0x7f010030;
        public static final int showText = 0x7f01004c;
        public static final int singleChoiceItemLayout = 0x7f010022;
        public static final int spinBars = 0x7f010028;
        public static final int spinnerDropDownItemStyle = 0x7f01007a;
        public static final int spinnerStyle = 0x7f0100b5;
        public static final int splitTrack = 0x7f01004b;
        public static final int state_above_anchor = 0x7f010038;
        public static final int submitBackground = 0x7f010045;
        public static final int subtitle = 0x7f010006;
        public static final int subtitleTextAppearance = 0x7f0100b8;
        public static final int subtitleTextColor = 0x7f0100c5;
        public static final int subtitleTextStyle = 0x7f010008;
        public static final int suggestionRowLayout = 0x7f010043;
        public static final int switchMinWidth = 0x7f010049;
        public static final int switchPadding = 0x7f01004a;
        public static final int switchStyle = 0x7f0100b6;
        public static final int switchTextAppearance = 0x7f010048;
        public static final int textAllCaps = 0x7f010024;
        public static final int textAppearanceLargePopupMenu = 0x7f010073;
        public static final int textAppearanceListItem = 0x7f010096;
        public static final int textAppearanceListItemSmall = 0x7f010097;
        public static final int textAppearanceSearchResultSubtitle = 0x7f01008c;
        public static final int textAppearanceSearchResultTitle = 0x7f01008b;
        public static final int textAppearanceSmallPopupMenu = 0x7f010074;
        public static final int textColorAlertDialogListItem = 0x7f0100a9;
        public static final int textColorSearchUrl = 0x7f01008d;
        public static final int theme = 0x7f0100c8;
        public static final int thickness = 0x7f01002e;
        public static final int thumbTextPadding = 0x7f010047;
        public static final int title = 0x7f010003;
        public static final int titleMarginBottom = 0x7f0100bd;
        public static final int titleMarginEnd = 0x7f0100bb;
        public static final int titleMarginStart = 0x7f0100ba;
        public static final int titleMarginTop = 0x7f0100bc;
        public static final int titleMargins = 0x7f0100b9;
        public static final int titleTextAppearance = 0x7f0100b7;
        public static final int titleTextColor = 0x7f0100c4;
        public static final int titleTextStyle = 0x7f010007;
        public static final int toolbarNavigationButtonStyle = 0x7f010086;
        public static final int toolbarStyle = 0x7f010085;
        public static final int track = 0x7f010046;
        public static final int voiceIcon = 0x7f010041;
        public static final int windowActionBar = 0x7f01004d;
        public static final int windowActionBarOverlay = 0x7f01004f;
        public static final int windowActionModeOverlay = 0x7f010050;
        public static final int windowFixedHeightMajor = 0x7f010054;
        public static final int windowFixedHeightMinor = 0x7f010052;
        public static final int windowFixedWidthMajor = 0x7f010051;
        public static final int windowFixedWidthMinor = 0x7f010053;
        public static final int windowMinWidthMajor = 0x7f010055;
        public static final int windowMinWidthMinor = 0x7f010056;
        public static final int windowNoTitle = 0x7f01004e;

        public attr()
        {
        }
    }

    public static final class bool
    {

        public static final int abc_action_bar_embed_tabs = 0x7f090002;
        public static final int abc_action_bar_embed_tabs_pre_jb = 0x7f090000;
        public static final int abc_action_bar_expanded_action_views_exclusive = 0x7f090003;
        public static final int abc_config_actionMenuItemAllCaps = 0x7f090004;
        public static final int abc_config_allowActionMenuItemTextWithIcon = 0x7f090001;
        public static final int abc_config_closeDialogWhenTouchOutside = 0x7f090005;
        public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 0x7f090006;

        public bool()
        {
        }
    }

    public static final class color
    {

        public static final int abc_background_cache_hint_selector_material_dark = 0x7f0b003d;
        public static final int abc_background_cache_hint_selector_material_light = 0x7f0b003e;
        public static final int abc_color_highlight_material = 0x7f0b003f;
        public static final int abc_input_method_navigation_guard = 0x7f0b0000;
        public static final int abc_primary_text_disable_only_material_dark = 0x7f0b0040;
        public static final int abc_primary_text_disable_only_material_light = 0x7f0b0041;
        public static final int abc_primary_text_material_dark = 0x7f0b0042;
        public static final int abc_primary_text_material_light = 0x7f0b0043;
        public static final int abc_search_url_text = 0x7f0b0044;
        public static final int abc_search_url_text_normal = 0x7f0b0001;
        public static final int abc_search_url_text_pressed = 0x7f0b0002;
        public static final int abc_search_url_text_selected = 0x7f0b0003;
        public static final int abc_secondary_text_material_dark = 0x7f0b0045;
        public static final int abc_secondary_text_material_light = 0x7f0b0046;
        public static final int accent_material_dark = 0x7f0b0004;
        public static final int accent_material_light = 0x7f0b0005;
        public static final int background_floating_material_dark = 0x7f0b0006;
        public static final int background_floating_material_light = 0x7f0b0007;
        public static final int background_material_dark = 0x7f0b0008;
        public static final int background_material_light = 0x7f0b0009;
        public static final int bright_foreground_disabled_material_dark = 0x7f0b000a;
        public static final int bright_foreground_disabled_material_light = 0x7f0b000b;
        public static final int bright_foreground_inverse_material_dark = 0x7f0b000c;
        public static final int bright_foreground_inverse_material_light = 0x7f0b000d;
        public static final int bright_foreground_material_dark = 0x7f0b000e;
        public static final int bright_foreground_material_light = 0x7f0b000f;
        public static final int button_material_dark = 0x7f0b0010;
        public static final int button_material_light = 0x7f0b0011;
        public static final int colorAccent = 0x7f0b0012;
        public static final int colorPrimary = 0x7f0b0013;
        public static final int colorPrimaryDark = 0x7f0b0014;
        public static final int dim_foreground_disabled_material_dark = 0x7f0b0015;
        public static final int dim_foreground_disabled_material_light = 0x7f0b0016;
        public static final int dim_foreground_material_dark = 0x7f0b0017;
        public static final int dim_foreground_material_light = 0x7f0b0018;
        public static final int foreground_material_dark = 0x7f0b0019;
        public static final int foreground_material_light = 0x7f0b001a;
        public static final int highlighted_text_material_dark = 0x7f0b001b;
        public static final int highlighted_text_material_light = 0x7f0b001c;
        public static final int hint_foreground_material_dark = 0x7f0b001d;
        public static final int hint_foreground_material_light = 0x7f0b001e;
        public static final int material_blue_grey_800 = 0x7f0b001f;
        public static final int material_blue_grey_900 = 0x7f0b0020;
        public static final int material_blue_grey_950 = 0x7f0b0021;
        public static final int material_deep_teal_200 = 0x7f0b0022;
        public static final int material_deep_teal_500 = 0x7f0b0023;
        public static final int material_grey_100 = 0x7f0b0024;
        public static final int material_grey_300 = 0x7f0b0025;
        public static final int material_grey_50 = 0x7f0b0026;
        public static final int material_grey_600 = 0x7f0b0027;
        public static final int material_grey_800 = 0x7f0b0028;
        public static final int material_grey_850 = 0x7f0b0029;
        public static final int material_grey_900 = 0x7f0b002a;
        public static final int primary_dark_material_dark = 0x7f0b002b;
        public static final int primary_dark_material_light = 0x7f0b002c;
        public static final int primary_material_dark = 0x7f0b002d;
        public static final int primary_material_light = 0x7f0b002e;
        public static final int primary_text_default_material_dark = 0x7f0b002f;
        public static final int primary_text_default_material_light = 0x7f0b0030;
        public static final int primary_text_disabled_material_dark = 0x7f0b0031;
        public static final int primary_text_disabled_material_light = 0x7f0b0032;
        public static final int ripple_material_dark = 0x7f0b0033;
        public static final int ripple_material_light = 0x7f0b0034;
        public static final int secondary_text_default_material_dark = 0x7f0b0035;
        public static final int secondary_text_default_material_light = 0x7f0b0036;
        public static final int secondary_text_disabled_material_dark = 0x7f0b0037;
        public static final int secondary_text_disabled_material_light = 0x7f0b0038;
        public static final int switch_thumb_disabled_material_dark = 0x7f0b0039;
        public static final int switch_thumb_disabled_material_light = 0x7f0b003a;
        public static final int switch_thumb_material_dark = 0x7f0b0047;
        public static final int switch_thumb_material_light = 0x7f0b0048;
        public static final int switch_thumb_normal_material_dark = 0x7f0b003b;
        public static final int switch_thumb_normal_material_light = 0x7f0b003c;

        public color()
        {
        }
    }

    public static final class dimen
    {

        public static final int abc_action_bar_content_inset_material = 0x7f07000b;
        public static final int abc_action_bar_default_height_material = 0x7f070001;
        public static final int abc_action_bar_default_padding_end_material = 0x7f07000c;
        public static final int abc_action_bar_default_padding_start_material = 0x7f07000d;
        public static final int abc_action_bar_icon_vertical_padding_material = 0x7f070010;
        public static final int abc_action_bar_overflow_padding_end_material = 0x7f070011;
        public static final int abc_action_bar_overflow_padding_start_material = 0x7f070012;
        public static final int abc_action_bar_progress_bar_size = 0x7f070002;
        public static final int abc_action_bar_stacked_max_height = 0x7f070013;
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f070014;
        public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f070015;
        public static final int abc_action_bar_subtitle_top_margin_material = 0x7f070016;
        public static final int abc_action_button_min_height_material = 0x7f070017;
        public static final int abc_action_button_min_width_material = 0x7f070018;
        public static final int abc_action_button_min_width_overflow_material = 0x7f070019;
        public static final int abc_alert_dialog_button_bar_height = 0x7f070000;
        public static final int abc_button_inset_horizontal_material = 0x7f07001a;
        public static final int abc_button_inset_vertical_material = 0x7f07001b;
        public static final int abc_button_padding_horizontal_material = 0x7f07001c;
        public static final int abc_button_padding_vertical_material = 0x7f07001d;
        public static final int abc_config_prefDialogWidth = 0x7f070005;
        public static final int abc_control_corner_material = 0x7f07001e;
        public static final int abc_control_inset_material = 0x7f07001f;
        public static final int abc_control_padding_material = 0x7f070020;
        public static final int abc_dialog_list_padding_vertical_material = 0x7f070021;
        public static final int abc_dialog_min_width_major = 0x7f070022;
        public static final int abc_dialog_min_width_minor = 0x7f070023;
        public static final int abc_dialog_padding_material = 0x7f070024;
        public static final int abc_dialog_padding_top_material = 0x7f070025;
        public static final int abc_disabled_alpha_material_dark = 0x7f070026;
        public static final int abc_disabled_alpha_material_light = 0x7f070027;
        public static final int abc_dropdownitem_icon_width = 0x7f070028;
        public static final int abc_dropdownitem_text_padding_left = 0x7f070029;
        public static final int abc_dropdownitem_text_padding_right = 0x7f07002a;
        public static final int abc_edit_text_inset_bottom_material = 0x7f07002b;
        public static final int abc_edit_text_inset_horizontal_material = 0x7f07002c;
        public static final int abc_edit_text_inset_top_material = 0x7f07002d;
        public static final int abc_floating_window_z = 0x7f07002e;
        public static final int abc_list_item_padding_horizontal_material = 0x7f07002f;
        public static final int abc_panel_menu_list_width = 0x7f070030;
        public static final int abc_search_view_preferred_width = 0x7f070031;
        public static final int abc_search_view_text_min_width = 0x7f070006;
        public static final int abc_switch_padding = 0x7f07000e;
        public static final int abc_text_size_body_1_material = 0x7f070032;
        public static final int abc_text_size_body_2_material = 0x7f070033;
        public static final int abc_text_size_button_material = 0x7f070034;
        public static final int abc_text_size_caption_material = 0x7f070035;
        public static final int abc_text_size_display_1_material = 0x7f070036;
        public static final int abc_text_size_display_2_material = 0x7f070037;
        public static final int abc_text_size_display_3_material = 0x7f070038;
        public static final int abc_text_size_display_4_material = 0x7f070039;
        public static final int abc_text_size_headline_material = 0x7f07003a;
        public static final int abc_text_size_large_material = 0x7f07003b;
        public static final int abc_text_size_medium_material = 0x7f07003c;
        public static final int abc_text_size_menu_material = 0x7f07003d;
        public static final int abc_text_size_small_material = 0x7f07003e;
        public static final int abc_text_size_subhead_material = 0x7f07003f;
        public static final int abc_text_size_subtitle_material_toolbar = 0x7f070003;
        public static final int abc_text_size_title_material = 0x7f070040;
        public static final int abc_text_size_title_material_toolbar = 0x7f070004;
        public static final int activity_horizontal_margin = 0x7f07000f;
        public static final int activity_vertical_margin = 0x7f070041;
        public static final int dialog_fixed_height_major = 0x7f070007;
        public static final int dialog_fixed_height_minor = 0x7f070008;
        public static final int dialog_fixed_width_major = 0x7f070009;
        public static final int dialog_fixed_width_minor = 0x7f07000a;
        public static final int disabled_alpha_material_dark = 0x7f070042;
        public static final int disabled_alpha_material_light = 0x7f070043;
        public static final int highlight_alpha_material_colored = 0x7f070044;
        public static final int highlight_alpha_material_dark = 0x7f070045;
        public static final int highlight_alpha_material_light = 0x7f070046;
        public static final int notification_large_icon_height = 0x7f070047;
        public static final int notification_large_icon_width = 0x7f070048;
        public static final int notification_subtext_size = 0x7f070049;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int abc_ab_share_pack_mtrl_alpha = 0x7f020000;
        public static final int abc_action_bar_item_background_material = 0x7f020001;
        public static final int abc_btn_borderless_material = 0x7f020002;
        public static final int abc_btn_check_material = 0x7f020003;
        public static final int abc_btn_check_to_on_mtrl_000 = 0x7f020004;
        public static final int abc_btn_check_to_on_mtrl_015 = 0x7f020005;
        public static final int abc_btn_colored_material = 0x7f020006;
        public static final int abc_btn_default_mtrl_shape = 0x7f020007;
        public static final int abc_btn_radio_material = 0x7f020008;
        public static final int abc_btn_radio_to_on_mtrl_000 = 0x7f020009;
        public static final int abc_btn_radio_to_on_mtrl_015 = 0x7f02000a;
        public static final int abc_btn_rating_star_off_mtrl_alpha = 0x7f02000b;
        public static final int abc_btn_rating_star_on_mtrl_alpha = 0x7f02000c;
        public static final int abc_btn_switch_to_on_mtrl_00001 = 0x7f02000d;
        public static final int abc_btn_switch_to_on_mtrl_00012 = 0x7f02000e;
        public static final int abc_cab_background_internal_bg = 0x7f02000f;
        public static final int abc_cab_background_top_material = 0x7f020010;
        public static final int abc_cab_background_top_mtrl_alpha = 0x7f020011;
        public static final int abc_control_background_material = 0x7f020012;
        public static final int abc_dialog_material_background_dark = 0x7f020013;
        public static final int abc_dialog_material_background_light = 0x7f020014;
        public static final int abc_edit_text_material = 0x7f020015;
        public static final int abc_ic_ab_back_mtrl_am_alpha = 0x7f020016;
        public static final int abc_ic_clear_mtrl_alpha = 0x7f020017;
        public static final int abc_ic_commit_search_api_mtrl_alpha = 0x7f020018;
        public static final int abc_ic_go_search_api_mtrl_alpha = 0x7f020019;
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f02001a;
        public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f02001b;
        public static final int abc_ic_menu_moreoverflow_mtrl_alpha = 0x7f02001c;
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f02001d;
        public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f02001e;
        public static final int abc_ic_menu_share_mtrl_alpha = 0x7f02001f;
        public static final int abc_ic_search_api_mtrl_alpha = 0x7f020020;
        public static final int abc_ic_voice_search_api_mtrl_alpha = 0x7f020021;
        public static final int abc_item_background_holo_dark = 0x7f020022;
        public static final int abc_item_background_holo_light = 0x7f020023;
        public static final int abc_list_divider_mtrl_alpha = 0x7f020024;
        public static final int abc_list_focused_holo = 0x7f020025;
        public static final int abc_list_longpressed_holo = 0x7f020026;
        public static final int abc_list_pressed_holo_dark = 0x7f020027;
        public static final int abc_list_pressed_holo_light = 0x7f020028;
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f020029;
        public static final int abc_list_selector_background_transition_holo_light = 0x7f02002a;
        public static final int abc_list_selector_disabled_holo_dark = 0x7f02002b;
        public static final int abc_list_selector_disabled_holo_light = 0x7f02002c;
        public static final int abc_list_selector_holo_dark = 0x7f02002d;
        public static final int abc_list_selector_holo_light = 0x7f02002e;
        public static final int abc_menu_hardkey_panel_mtrl_mult = 0x7f02002f;
        public static final int abc_popup_background_mtrl_mult = 0x7f020030;
        public static final int abc_ratingbar_full_material = 0x7f020031;
        public static final int abc_spinner_mtrl_am_alpha = 0x7f020032;
        public static final int abc_spinner_textfield_background_material = 0x7f020033;
        public static final int abc_switch_thumb_material = 0x7f020034;
        public static final int abc_switch_track_mtrl_alpha = 0x7f020035;
        public static final int abc_tab_indicator_material = 0x7f020036;
        public static final int abc_tab_indicator_mtrl_alpha = 0x7f020037;
        public static final int abc_text_cursor_material = 0x7f020038;
        public static final int abc_textfield_activated_mtrl_alpha = 0x7f020039;
        public static final int abc_textfield_default_mtrl_alpha = 0x7f02003a;
        public static final int abc_textfield_search_activated_mtrl_alpha = 0x7f02003b;
        public static final int abc_textfield_search_default_mtrl_alpha = 0x7f02003c;
        public static final int abc_textfield_search_material = 0x7f02003d;
        public static final int notification_template_icon_bg = 0x7f02003e;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int action0 = 0x7f0c0053;
        public static final int action_bar = 0x7f0c003e;
        public static final int action_bar_activity_content = 0x7f0c0000;
        public static final int action_bar_container = 0x7f0c003d;
        public static final int action_bar_root = 0x7f0c0039;
        public static final int action_bar_spinner = 0x7f0c0001;
        public static final int action_bar_subtitle = 0x7f0c0022;
        public static final int action_bar_title = 0x7f0c0021;
        public static final int action_context_bar = 0x7f0c003f;
        public static final int action_divider = 0x7f0c0057;
        public static final int action_menu_divider = 0x7f0c0002;
        public static final int action_menu_presenter = 0x7f0c0003;
        public static final int action_mode_bar = 0x7f0c003b;
        public static final int action_mode_bar_stub = 0x7f0c003a;
        public static final int action_mode_close_button = 0x7f0c0023;
        public static final int activity_chooser_view_content = 0x7f0c0024;
        public static final int alertTitle = 0x7f0c002e;
        public static final int always = 0x7f0c001b;
        public static final int beginning = 0x7f0c0018;
        public static final int button = 0x7f0c004d;
        public static final int button3 = 0x7f0c004f;
        public static final int buttonPanel = 0x7f0c0034;
        public static final int buttonR = 0x7f0c004e;
        public static final int cancel_action = 0x7f0c0054;
        public static final int checkbox = 0x7f0c0036;
        public static final int chronometer = 0x7f0c005a;
        public static final int collapseActionView = 0x7f0c001c;
        public static final int contentPanel = 0x7f0c002f;
        public static final int custom = 0x7f0c0033;
        public static final int customPanel = 0x7f0c0032;
        public static final int decor_content_parent = 0x7f0c003c;
        public static final int default_activity_button = 0x7f0c0027;
        public static final int disableHome = 0x7f0c000c;
        public static final int edit_query = 0x7f0c0040;
        public static final int end = 0x7f0c0019;
        public static final int end_padder = 0x7f0c005f;
        public static final int expand_activities_button = 0x7f0c0025;
        public static final int expanded_menu = 0x7f0c0035;
        public static final int home = 0x7f0c0004;
        public static final int homeAsUp = 0x7f0c000d;
        public static final int icon = 0x7f0c0029;
        public static final int ifRoom = 0x7f0c001d;
        public static final int image = 0x7f0c0026;
        public static final int info = 0x7f0c005e;
        public static final int line1 = 0x7f0c0058;
        public static final int line3 = 0x7f0c005c;
        public static final int listMode = 0x7f0c0009;
        public static final int list_item = 0x7f0c0028;
        public static final int media_actions = 0x7f0c0056;
        public static final int middle = 0x7f0c001a;
        public static final int multiply = 0x7f0c0013;
        public static final int never = 0x7f0c001e;
        public static final int none = 0x7f0c000e;
        public static final int normal = 0x7f0c000a;
        public static final int parentPanel = 0x7f0c002b;
        public static final int progress_circular = 0x7f0c0005;
        public static final int progress_horizontal = 0x7f0c0006;
        public static final int radio = 0x7f0c0038;
        public static final int screen = 0x7f0c0014;
        public static final int scrollView = 0x7f0c0030;
        public static final int search_badge = 0x7f0c0042;
        public static final int search_bar = 0x7f0c0041;
        public static final int search_button = 0x7f0c0043;
        public static final int search_close_btn = 0x7f0c0048;
        public static final int search_edit_frame = 0x7f0c0044;
        public static final int search_go_btn = 0x7f0c004a;
        public static final int search_mag_icon = 0x7f0c0045;
        public static final int search_plate = 0x7f0c0046;
        public static final int search_src_text = 0x7f0c0047;
        public static final int search_voice_btn = 0x7f0c004b;
        public static final int select_dialog_listview = 0x7f0c004c;
        public static final int shortcut = 0x7f0c0037;
        public static final int showCustom = 0x7f0c000f;
        public static final int showHome = 0x7f0c0010;
        public static final int showTitle = 0x7f0c0011;
        public static final int split_action_bar = 0x7f0c0007;
        public static final int src_atop = 0x7f0c0015;
        public static final int src_in = 0x7f0c0016;
        public static final int src_over = 0x7f0c0017;
        public static final int status_bar_latest_event_content = 0x7f0c0055;
        public static final int submit_area = 0x7f0c0049;
        public static final int tabMode = 0x7f0c000b;
        public static final int text = 0x7f0c005d;
        public static final int text2 = 0x7f0c005b;
        public static final int textSpacerNoButtons = 0x7f0c0031;
        public static final int textView = 0x7f0c0050;
        public static final int textView2 = 0x7f0c0051;
        public static final int textView3 = 0x7f0c0052;
        public static final int time = 0x7f0c0059;
        public static final int title = 0x7f0c002a;
        public static final int title_template = 0x7f0c002d;
        public static final int topPanel = 0x7f0c002c;
        public static final int up = 0x7f0c0008;
        public static final int useLogo = 0x7f0c0012;
        public static final int withText = 0x7f0c001f;
        public static final int wrap_content = 0x7f0c0020;

        public id()
        {
        }
    }

    public static final class integer
    {

        public static final int abc_config_activityDefaultDur = 0x7f0a0001;
        public static final int abc_config_activityShortDur = 0x7f0a0002;
        public static final int abc_max_action_buttons = 0x7f0a0000;
        public static final int cancel_button_image_alpha = 0x7f0a0003;
        public static final int status_bar_notification_info_maxnum = 0x7f0a0004;

        public integer()
        {
        }
    }

    public static final class layout
    {

        public static final int abc_action_bar_title_item = 0x7f040000;
        public static final int abc_action_bar_up_container = 0x7f040001;
        public static final int abc_action_bar_view_list_nav_layout = 0x7f040002;
        public static final int abc_action_menu_item_layout = 0x7f040003;
        public static final int abc_action_menu_layout = 0x7f040004;
        public static final int abc_action_mode_bar = 0x7f040005;
        public static final int abc_action_mode_close_item_material = 0x7f040006;
        public static final int abc_activity_chooser_view = 0x7f040007;
        public static final int abc_activity_chooser_view_list_item = 0x7f040008;
        public static final int abc_alert_dialog_material = 0x7f040009;
        public static final int abc_dialog_title_material = 0x7f04000a;
        public static final int abc_expanded_menu_layout = 0x7f04000b;
        public static final int abc_list_menu_item_checkbox = 0x7f04000c;
        public static final int abc_list_menu_item_icon = 0x7f04000d;
        public static final int abc_list_menu_item_layout = 0x7f04000e;
        public static final int abc_list_menu_item_radio = 0x7f04000f;
        public static final int abc_popup_menu_item_layout = 0x7f040010;
        public static final int abc_screen_content_include = 0x7f040011;
        public static final int abc_screen_simple = 0x7f040012;
        public static final int abc_screen_simple_overlay_action_mode = 0x7f040013;
        public static final int abc_screen_toolbar = 0x7f040014;
        public static final int abc_search_dropdown_item_icons_2line = 0x7f040015;
        public static final int abc_search_view = 0x7f040016;
        public static final int abc_select_dialog_material = 0x7f040017;
        public static final int activity_main = 0x7f040018;
        public static final int notification_media_action = 0x7f040019;
        public static final int notification_media_cancel_action = 0x7f04001a;
        public static final int notification_template_big_media = 0x7f04001b;
        public static final int notification_template_big_media_narrow = 0x7f04001c;
        public static final int notification_template_lines = 0x7f04001d;
        public static final int notification_template_media = 0x7f04001e;
        public static final int notification_template_part_chronometer = 0x7f04001f;
        public static final int notification_template_part_time = 0x7f040020;
        public static final int select_dialog_item_material = 0x7f040021;
        public static final int select_dialog_multichoice_material = 0x7f040022;
        public static final int select_dialog_singlechoice_material = 0x7f040023;
        public static final int support_simple_spinner_dropdown_item = 0x7f040024;

        public layout()
        {
        }
    }

    public static final class mipmap
    {

        public static final int ic_launcher = 0x7f030000;

        public mipmap()
        {
        }
    }

    public static final class string
    {

        public static final int abc_action_bar_home_description = 0x7f060000;
        public static final int abc_action_bar_home_description_format = 0x7f060001;
        public static final int abc_action_bar_home_subtitle_description_format = 0x7f060002;
        public static final int abc_action_bar_up_description = 0x7f060003;
        public static final int abc_action_menu_overflow_description = 0x7f060004;
        public static final int abc_action_mode_done = 0x7f060005;
        public static final int abc_activity_chooser_view_see_all = 0x7f060006;
        public static final int abc_activitychooserview_choose_application = 0x7f060007;
        public static final int abc_search_hint = 0x7f060008;
        public static final int abc_searchview_description_clear = 0x7f060009;
        public static final int abc_searchview_description_query = 0x7f06000a;
        public static final int abc_searchview_description_search = 0x7f06000b;
        public static final int abc_searchview_description_submit = 0x7f06000c;
        public static final int abc_searchview_description_voice = 0x7f06000d;
        public static final int abc_shareactionprovider_share_with = 0x7f06000e;
        public static final int abc_shareactionprovider_share_with_application = 0x7f06000f;
        public static final int abc_toolbar_collapse_description = 0x7f060010;
        public static final int app_name = 0x7f060012;
        public static final int app_text = 0x7f060013;
        public static final int status_bar_notification_info_overflow = 0x7f060011;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AlertDialog_AppCompat = 0x7f08007a;
        public static final int AlertDialog_AppCompat_Light = 0x7f08007b;
        public static final int Animation_AppCompat_Dialog = 0x7f08007c;
        public static final int Animation_AppCompat_DropDownUp = 0x7f08007d;
        public static final int AppTheme = 0x7f08007e;
        public static final int Base_AlertDialog_AppCompat = 0x7f08007f;
        public static final int Base_AlertDialog_AppCompat_Light = 0x7f080080;
        public static final int Base_Animation_AppCompat_Dialog = 0x7f080081;
        public static final int Base_Animation_AppCompat_DropDownUp = 0x7f080082;
        public static final int Base_DialogWindowTitleBackground_AppCompat = 0x7f080084;
        public static final int Base_DialogWindowTitle_AppCompat = 0x7f080083;
        public static final int Base_TextAppearance_AppCompat = 0x7f08002d;
        public static final int Base_TextAppearance_AppCompat_Body1 = 0x7f08002e;
        public static final int Base_TextAppearance_AppCompat_Body2 = 0x7f08002f;
        public static final int Base_TextAppearance_AppCompat_Button = 0x7f080018;
        public static final int Base_TextAppearance_AppCompat_Caption = 0x7f080030;
        public static final int Base_TextAppearance_AppCompat_Display1 = 0x7f080031;
        public static final int Base_TextAppearance_AppCompat_Display2 = 0x7f080032;
        public static final int Base_TextAppearance_AppCompat_Display3 = 0x7f080033;
        public static final int Base_TextAppearance_AppCompat_Display4 = 0x7f080034;
        public static final int Base_TextAppearance_AppCompat_Headline = 0x7f080035;
        public static final int Base_TextAppearance_AppCompat_Inverse = 0x7f080003;
        public static final int Base_TextAppearance_AppCompat_Large = 0x7f080036;
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f080004;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f080037;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f080038;
        public static final int Base_TextAppearance_AppCompat_Medium = 0x7f080039;
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f080005;
        public static final int Base_TextAppearance_AppCompat_Menu = 0x7f08003a;
        public static final int Base_TextAppearance_AppCompat_SearchResult = 0x7f080085;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f08003b;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f08003c;
        public static final int Base_TextAppearance_AppCompat_Small = 0x7f08003d;
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f080006;
        public static final int Base_TextAppearance_AppCompat_Subhead = 0x7f08003e;
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f080007;
        public static final int Base_TextAppearance_AppCompat_Title = 0x7f08003f;
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f080008;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f080040;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f080041;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f080042;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f080043;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f080044;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f080045;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f080046;
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 0x7f080047;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f080076;
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f080086;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f080048;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f080049;
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f08004a;
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f08004b;
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f080087;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f08004c;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f08004d;
        public static final int Base_ThemeOverlay_AppCompat = 0x7f080090;
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f080091;
        public static final int Base_ThemeOverlay_AppCompat_Dark = 0x7f080092;
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f080093;
        public static final int Base_ThemeOverlay_AppCompat_Light = 0x7f080094;
        public static final int Base_Theme_AppCompat = 0x7f08004e;
        public static final int Base_Theme_AppCompat_CompactMenu = 0x7f080088;
        public static final int Base_Theme_AppCompat_Dialog = 0x7f080009;
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 0x7f080001;
        public static final int Base_Theme_AppCompat_Dialog_Alert = 0x7f080089;
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f08008a;
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 0x7f08008b;
        public static final int Base_Theme_AppCompat_Light = 0x7f08004f;
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f08008c;
        public static final int Base_Theme_AppCompat_Light_Dialog = 0x7f08000a;
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f080002;
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 0x7f08008d;
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f08008e;
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 0x7f08008f;
        public static final int Base_V11_Theme_AppCompat_Dialog = 0x7f08000b;
        public static final int Base_V11_Theme_AppCompat_Light_Dialog = 0x7f08000c;
        public static final int Base_V12_Widget_AppCompat_AutoCompleteTextView = 0x7f080014;
        public static final int Base_V12_Widget_AppCompat_EditText = 0x7f080015;
        public static final int Base_V21_Theme_AppCompat = 0x7f080050;
        public static final int Base_V21_Theme_AppCompat_Dialog = 0x7f080051;
        public static final int Base_V21_Theme_AppCompat_Light = 0x7f080052;
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f080053;
        public static final int Base_V22_Theme_AppCompat = 0x7f080074;
        public static final int Base_V22_Theme_AppCompat_Light = 0x7f080075;
        public static final int Base_V23_Theme_AppCompat = 0x7f080077;
        public static final int Base_V23_Theme_AppCompat_Light = 0x7f080078;
        public static final int Base_V7_Theme_AppCompat = 0x7f080095;
        public static final int Base_V7_Theme_AppCompat_Dialog = 0x7f080096;
        public static final int Base_V7_Theme_AppCompat_Light = 0x7f080097;
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 0x7f080098;
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 0x7f080099;
        public static final int Base_V7_Widget_AppCompat_EditText = 0x7f08009a;
        public static final int Base_Widget_AppCompat_ActionBar = 0x7f08009b;
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 0x7f08009c;
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f08009d;
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 0x7f080054;
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 0x7f080055;
        public static final int Base_Widget_AppCompat_ActionButton = 0x7f080056;
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f080057;
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f080058;
        public static final int Base_Widget_AppCompat_ActionMode = 0x7f08009e;
        public static final int Base_Widget_AppCompat_ActivityChooserView = 0x7f08009f;
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f080016;
        public static final int Base_Widget_AppCompat_Button = 0x7f080059;
        public static final int Base_Widget_AppCompat_ButtonBar = 0x7f08005d;
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 0x7f0800a1;
        public static final int Base_Widget_AppCompat_Button_Borderless = 0x7f08005a;
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 0x7f08005b;
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f0800a0;
        public static final int Base_Widget_AppCompat_Button_Colored = 0x7f080079;
        public static final int Base_Widget_AppCompat_Button_Small = 0x7f08005c;
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 0x7f08005e;
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 0x7f08005f;
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f0800a2;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f080000;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 0x7f0800a3;
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f080060;
        public static final int Base_Widget_AppCompat_EditText = 0x7f080017;
        public static final int Base_Widget_AppCompat_Light_ActionBar = 0x7f0800a4;
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f0800a5;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0800a6;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f080061;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f080062;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f080063;
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 0x7f080064;
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f080065;
        public static final int Base_Widget_AppCompat_ListPopupWindow = 0x7f080066;
        public static final int Base_Widget_AppCompat_ListView = 0x7f080067;
        public static final int Base_Widget_AppCompat_ListView_DropDown = 0x7f080068;
        public static final int Base_Widget_AppCompat_ListView_Menu = 0x7f080069;
        public static final int Base_Widget_AppCompat_PopupMenu = 0x7f08006a;
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f08006b;
        public static final int Base_Widget_AppCompat_PopupWindow = 0x7f0800a7;
        public static final int Base_Widget_AppCompat_ProgressBar = 0x7f08000d;
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 0x7f08000e;
        public static final int Base_Widget_AppCompat_RatingBar = 0x7f08006c;
        public static final int Base_Widget_AppCompat_SearchView = 0x7f0800a8;
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 0x7f0800a9;
        public static final int Base_Widget_AppCompat_Spinner = 0x7f08006d;
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 0x7f08006e;
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 0x7f08006f;
        public static final int Base_Widget_AppCompat_Toolbar = 0x7f0800aa;
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f080070;
        public static final int Platform_AppCompat = 0x7f08000f;
        public static final int Platform_AppCompat_Light = 0x7f080010;
        public static final int Platform_ThemeOverlay_AppCompat = 0x7f080071;
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 0x7f080072;
        public static final int Platform_ThemeOverlay_AppCompat_Light = 0x7f080073;
        public static final int Platform_V11_AppCompat = 0x7f080011;
        public static final int Platform_V11_AppCompat_Light = 0x7f080012;
        public static final int Platform_V14_AppCompat = 0x7f080019;
        public static final int Platform_V14_AppCompat_Light = 0x7f08001a;
        public static final int Platform_Widget_AppCompat_Spinner = 0x7f080013;
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 0x7f080020;
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f080021;
        public static final int RtlOverlay_Widget_AppCompat_ActionButton_Overflow = 0x7f080022;
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 0x7f080023;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f080024;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f080025;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f080026;
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f08002c;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f080027;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f080028;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f080029;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f08002a;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f08002b;
        public static final int TextAppearance_AppCompat = 0x7f0800ab;
        public static final int TextAppearance_AppCompat_Body1 = 0x7f0800ac;
        public static final int TextAppearance_AppCompat_Body2 = 0x7f0800ad;
        public static final int TextAppearance_AppCompat_Button = 0x7f0800ae;
        public static final int TextAppearance_AppCompat_Caption = 0x7f0800af;
        public static final int TextAppearance_AppCompat_Display1 = 0x7f0800b0;
        public static final int TextAppearance_AppCompat_Display2 = 0x7f0800b1;
        public static final int TextAppearance_AppCompat_Display3 = 0x7f0800b2;
        public static final int TextAppearance_AppCompat_Display4 = 0x7f0800b3;
        public static final int TextAppearance_AppCompat_Headline = 0x7f0800b4;
        public static final int TextAppearance_AppCompat_Inverse = 0x7f0800b5;
        public static final int TextAppearance_AppCompat_Large = 0x7f0800b6;
        public static final int TextAppearance_AppCompat_Large_Inverse = 0x7f0800b7;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f0800b8;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f0800b9;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0800ba;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0800bb;
        public static final int TextAppearance_AppCompat_Medium = 0x7f0800bc;
        public static final int TextAppearance_AppCompat_Medium_Inverse = 0x7f0800bd;
        public static final int TextAppearance_AppCompat_Menu = 0x7f0800be;
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0800bf;
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f0800c0;
        public static final int TextAppearance_AppCompat_Small = 0x7f0800c1;
        public static final int TextAppearance_AppCompat_Small_Inverse = 0x7f0800c2;
        public static final int TextAppearance_AppCompat_Subhead = 0x7f0800c3;
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 0x7f0800c4;
        public static final int TextAppearance_AppCompat_Title = 0x7f0800c5;
        public static final int TextAppearance_AppCompat_Title_Inverse = 0x7f0800c6;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0800c7;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0800c8;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0800c9;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f0800ca;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f0800cb;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f0800cc;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f0800cd;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f0800ce;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f0800cf;
        public static final int TextAppearance_AppCompat_Widget_Button = 0x7f0800d0;
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f0800d1;
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0800d2;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f0800d3;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f0800d4;
        public static final int TextAppearance_AppCompat_Widget_Switch = 0x7f0800d5;
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f0800d6;
        public static final int TextAppearance_StatusBar_EventContent = 0x7f08001b;
        public static final int TextAppearance_StatusBar_EventContent_Info = 0x7f08001c;
        public static final int TextAppearance_StatusBar_EventContent_Line2 = 0x7f08001d;
        public static final int TextAppearance_StatusBar_EventContent_Time = 0x7f08001e;
        public static final int TextAppearance_StatusBar_EventContent_Title = 0x7f08001f;
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0800d7;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f0800d8;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f0800d9;
        public static final int ThemeOverlay_AppCompat = 0x7f0800e8;
        public static final int ThemeOverlay_AppCompat_ActionBar = 0x7f0800e9;
        public static final int ThemeOverlay_AppCompat_Dark = 0x7f0800ea;
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f0800eb;
        public static final int ThemeOverlay_AppCompat_Light = 0x7f0800ec;
        public static final int Theme_AppCompat = 0x7f0800da;
        public static final int Theme_AppCompat_CompactMenu = 0x7f0800db;
        public static final int Theme_AppCompat_Dialog = 0x7f0800dc;
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f0800df;
        public static final int Theme_AppCompat_Dialog_Alert = 0x7f0800dd;
        public static final int Theme_AppCompat_Dialog_MinWidth = 0x7f0800de;
        public static final int Theme_AppCompat_Light = 0x7f0800e0;
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f0800e1;
        public static final int Theme_AppCompat_Light_Dialog = 0x7f0800e2;
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f0800e5;
        public static final int Theme_AppCompat_Light_Dialog_Alert = 0x7f0800e3;
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 0x7f0800e4;
        public static final int Theme_AppCompat_Light_NoActionBar = 0x7f0800e6;
        public static final int Theme_AppCompat_NoActionBar = 0x7f0800e7;
        public static final int Widget_AppCompat_ActionBar = 0x7f0800ed;
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f0800ee;
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f0800ef;
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f0800f0;
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f0800f1;
        public static final int Widget_AppCompat_ActionButton = 0x7f0800f2;
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f0800f3;
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f0800f4;
        public static final int Widget_AppCompat_ActionMode = 0x7f0800f5;
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f0800f6;
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f0800f7;
        public static final int Widget_AppCompat_Button = 0x7f0800f8;
        public static final int Widget_AppCompat_ButtonBar = 0x7f0800fe;
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 0x7f0800ff;
        public static final int Widget_AppCompat_Button_Borderless = 0x7f0800f9;
        public static final int Widget_AppCompat_Button_Borderless_Colored = 0x7f0800fa;
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f0800fb;
        public static final int Widget_AppCompat_Button_Colored = 0x7f0800fc;
        public static final int Widget_AppCompat_Button_Small = 0x7f0800fd;
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 0x7f080100;
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 0x7f080101;
        public static final int Widget_AppCompat_CompoundButton_Switch = 0x7f080102;
        public static final int Widget_AppCompat_DrawerArrowToggle = 0x7f080103;
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f080104;
        public static final int Widget_AppCompat_EditText = 0x7f080105;
        public static final int Widget_AppCompat_Light_ActionBar = 0x7f080106;
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f080107;
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f080108;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f080109;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f08010a;
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f08010b;
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f08010c;
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f08010d;
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f08010e;
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f08010f;
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f080110;
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f080111;
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f080112;
        public static final int Widget_AppCompat_Light_ActivityChooserView = 0x7f080113;
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f080114;
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f080115;
        public static final int Widget_AppCompat_Light_ListPopupWindow = 0x7f080116;
        public static final int Widget_AppCompat_Light_ListView_DropDown = 0x7f080117;
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f080118;
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f080119;
        public static final int Widget_AppCompat_Light_SearchView = 0x7f08011a;
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f08011b;
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f08011c;
        public static final int Widget_AppCompat_ListView = 0x7f08011d;
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f08011e;
        public static final int Widget_AppCompat_ListView_Menu = 0x7f08011f;
        public static final int Widget_AppCompat_PopupMenu = 0x7f080120;
        public static final int Widget_AppCompat_PopupMenu_Overflow = 0x7f080121;
        public static final int Widget_AppCompat_PopupWindow = 0x7f080122;
        public static final int Widget_AppCompat_ProgressBar = 0x7f080123;
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 0x7f080124;
        public static final int Widget_AppCompat_RatingBar = 0x7f080125;
        public static final int Widget_AppCompat_SearchView = 0x7f080126;
        public static final int Widget_AppCompat_SearchView_ActionBar = 0x7f080127;
        public static final int Widget_AppCompat_Spinner = 0x7f080128;
        public static final int Widget_AppCompat_Spinner_DropDown = 0x7f080129;
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f08012a;
        public static final int Widget_AppCompat_Spinner_Underlined = 0x7f08012b;
        public static final int Widget_AppCompat_TextView_SpinnerItem = 0x7f08012c;
        public static final int Widget_AppCompat_Toolbar = 0x7f08012d;
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f08012e;

        public style()
        {
        }
    }

    public static final class styleable
    {

        public static final int ActionBar[] = {
            0x7f010001, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 
            0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 
            0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f01007b
        };
        public static final int ActionBarLayout[] = {
            0x10100b3
        };
        public static final int ActionBarLayout_android_layout_gravity = 0;
        public static final int ActionBar_background = 10;
        public static final int ActionBar_backgroundSplit = 12;
        public static final int ActionBar_backgroundStacked = 11;
        public static final int ActionBar_contentInsetEnd = 21;
        public static final int ActionBar_contentInsetLeft = 22;
        public static final int ActionBar_contentInsetRight = 23;
        public static final int ActionBar_contentInsetStart = 20;
        public static final int ActionBar_customNavigationLayout = 13;
        public static final int ActionBar_displayOptions = 3;
        public static final int ActionBar_divider = 9;
        public static final int ActionBar_elevation = 24;
        public static final int ActionBar_height = 0;
        public static final int ActionBar_hideOnContentScroll = 19;
        public static final int ActionBar_homeAsUpIndicator = 26;
        public static final int ActionBar_homeLayout = 14;
        public static final int ActionBar_icon = 7;
        public static final int ActionBar_indeterminateProgressStyle = 16;
        public static final int ActionBar_itemPadding = 18;
        public static final int ActionBar_logo = 8;
        public static final int ActionBar_navigationMode = 2;
        public static final int ActionBar_popupTheme = 25;
        public static final int ActionBar_progressBarPadding = 17;
        public static final int ActionBar_progressBarStyle = 15;
        public static final int ActionBar_subtitle = 4;
        public static final int ActionBar_subtitleTextStyle = 6;
        public static final int ActionBar_title = 1;
        public static final int ActionBar_titleTextStyle = 5;
        public static final int ActionMenuItemView[] = {
            0x101013f
        };
        public static final int ActionMenuItemView_android_minWidth = 0;
        public static final int ActionMenuView[] = new int[0];
        public static final int ActionMode[] = {
            0x7f010001, 0x7f010007, 0x7f010008, 0x7f01000c, 0x7f01000e, 0x7f01001c
        };
        public static final int ActionMode_background = 3;
        public static final int ActionMode_backgroundSplit = 4;
        public static final int ActionMode_closeItemLayout = 5;
        public static final int ActionMode_height = 0;
        public static final int ActionMode_subtitleTextStyle = 2;
        public static final int ActionMode_titleTextStyle = 1;
        public static final int ActivityChooserView[] = {
            0x7f01001d, 0x7f01001e
        };
        public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
        public static final int ActivityChooserView_initialActivityCount = 0;
        public static final int AlertDialog[] = {
            0x10100f2, 0x7f01001f, 0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023
        };
        public static final int AlertDialog_android_layout = 0;
        public static final int AlertDialog_buttonPanelSideLayout = 1;
        public static final int AlertDialog_listItemLayout = 5;
        public static final int AlertDialog_listLayout = 2;
        public static final int AlertDialog_multiChoiceItemLayout = 3;
        public static final int AlertDialog_singleChoiceItemLayout = 4;
        public static final int AppCompatTextView[] = {
            0x1010034, 0x7f010024
        };
        public static final int AppCompatTextView_android_textAppearance = 0;
        public static final int AppCompatTextView_textAllCaps = 1;
        public static final int CompoundButton[] = {
            0x1010107, 0x7f010025, 0x7f010026
        };
        public static final int CompoundButton_android_button = 0;
        public static final int CompoundButton_buttonTint = 1;
        public static final int CompoundButton_buttonTintMode = 2;
        public static final int DrawerArrowToggle[] = {
            0x7f010027, 0x7f010028, 0x7f010029, 0x7f01002a, 0x7f01002b, 0x7f01002c, 0x7f01002d, 0x7f01002e
        };
        public static final int DrawerArrowToggle_arrowHeadLength = 4;
        public static final int DrawerArrowToggle_arrowShaftLength = 5;
        public static final int DrawerArrowToggle_barLength = 6;
        public static final int DrawerArrowToggle_color = 0;
        public static final int DrawerArrowToggle_drawableSize = 2;
        public static final int DrawerArrowToggle_gapBetweenBars = 3;
        public static final int DrawerArrowToggle_spinBars = 1;
        public static final int DrawerArrowToggle_thickness = 7;
        public static final int LinearLayoutCompat[] = {
            0x10100af, 0x10100c4, 0x1010126, 0x1010127, 0x1010128, 0x7f01000b, 0x7f01002f, 0x7f010030, 0x7f010031
        };
        public static final int LinearLayoutCompat_Layout[] = {
            0x10100b3, 0x10100f4, 0x10100f5, 0x1010181
        };
        public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
        public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
        public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
        public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
        public static final int LinearLayoutCompat_android_baselineAligned = 2;
        public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
        public static final int LinearLayoutCompat_android_gravity = 0;
        public static final int LinearLayoutCompat_android_orientation = 1;
        public static final int LinearLayoutCompat_android_weightSum = 4;
        public static final int LinearLayoutCompat_divider = 5;
        public static final int LinearLayoutCompat_dividerPadding = 8;
        public static final int LinearLayoutCompat_measureWithLargestChild = 6;
        public static final int LinearLayoutCompat_showDividers = 7;
        public static final int ListPopupWindow[] = {
            0x10102ac, 0x10102ad
        };
        public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
        public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
        public static final int MenuGroup[] = {
            0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
        };
        public static final int MenuGroup_android_checkableBehavior = 5;
        public static final int MenuGroup_android_enabled = 0;
        public static final int MenuGroup_android_id = 1;
        public static final int MenuGroup_android_menuCategory = 3;
        public static final int MenuGroup_android_orderInCategory = 4;
        public static final int MenuGroup_android_visible = 2;
        public static final int MenuItem[] = {
            0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
            0x10101e4, 0x10101e5, 0x101026f, 0x7f010032, 0x7f010033, 0x7f010034, 0x7f010035
        };
        public static final int MenuItem_actionLayout = 14;
        public static final int MenuItem_actionProviderClass = 16;
        public static final int MenuItem_actionViewClass = 15;
        public static final int MenuItem_android_alphabeticShortcut = 9;
        public static final int MenuItem_android_checkable = 11;
        public static final int MenuItem_android_checked = 3;
        public static final int MenuItem_android_enabled = 1;
        public static final int MenuItem_android_icon = 0;
        public static final int MenuItem_android_id = 2;
        public static final int MenuItem_android_menuCategory = 5;
        public static final int MenuItem_android_numericShortcut = 10;
        public static final int MenuItem_android_onClick = 12;
        public static final int MenuItem_android_orderInCategory = 6;
        public static final int MenuItem_android_title = 7;
        public static final int MenuItem_android_titleCondensed = 8;
        public static final int MenuItem_android_visible = 4;
        public static final int MenuItem_showAsAction = 13;
        public static final int MenuView[] = {
            0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x7f010036
        };
        public static final int MenuView_android_headerBackground = 4;
        public static final int MenuView_android_horizontalDivider = 2;
        public static final int MenuView_android_itemBackground = 5;
        public static final int MenuView_android_itemIconDisabledAlpha = 6;
        public static final int MenuView_android_itemTextAppearance = 1;
        public static final int MenuView_android_verticalDivider = 3;
        public static final int MenuView_android_windowAnimationStyle = 0;
        public static final int MenuView_preserveIconSpacing = 7;
        public static final int PopupWindow[] = {
            0x1010176, 0x7f010037
        };
        public static final int PopupWindowBackgroundState[] = {
            0x7f010038
        };
        public static final int PopupWindowBackgroundState_state_above_anchor = 0;
        public static final int PopupWindow_android_popupBackground = 0;
        public static final int PopupWindow_overlapAnchor = 1;
        public static final int SearchView[] = {
            0x10100da, 0x101011f, 0x1010220, 0x1010264, 0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c, 0x7f01003d, 0x7f01003e, 
            0x7f01003f, 0x7f010040, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045
        };
        public static final int SearchView_android_focusable = 0;
        public static final int SearchView_android_imeOptions = 3;
        public static final int SearchView_android_inputType = 2;
        public static final int SearchView_android_maxWidth = 1;
        public static final int SearchView_closeIcon = 8;
        public static final int SearchView_commitIcon = 13;
        public static final int SearchView_defaultQueryHint = 7;
        public static final int SearchView_goIcon = 9;
        public static final int SearchView_iconifiedByDefault = 5;
        public static final int SearchView_layout = 4;
        public static final int SearchView_queryBackground = 15;
        public static final int SearchView_queryHint = 6;
        public static final int SearchView_searchHintIcon = 11;
        public static final int SearchView_searchIcon = 10;
        public static final int SearchView_submitBackground = 16;
        public static final int SearchView_suggestionRowLayout = 14;
        public static final int SearchView_voiceIcon = 12;
        public static final int Spinner[] = {
            0x1010176, 0x101017b, 0x1010262, 0x7f01001b
        };
        public static final int Spinner_android_dropDownWidth = 2;
        public static final int Spinner_android_popupBackground = 0;
        public static final int Spinner_android_prompt = 1;
        public static final int Spinner_popupTheme = 3;
        public static final int SwitchCompat[] = {
            0x1010124, 0x1010125, 0x1010142, 0x7f010046, 0x7f010047, 0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c
        };
        public static final int SwitchCompat_android_textOff = 1;
        public static final int SwitchCompat_android_textOn = 0;
        public static final int SwitchCompat_android_thumb = 2;
        public static final int SwitchCompat_showText = 9;
        public static final int SwitchCompat_splitTrack = 8;
        public static final int SwitchCompat_switchMinWidth = 6;
        public static final int SwitchCompat_switchPadding = 7;
        public static final int SwitchCompat_switchTextAppearance = 5;
        public static final int SwitchCompat_thumbTextPadding = 4;
        public static final int SwitchCompat_track = 3;
        public static final int TextAppearance[] = {
            0x1010095, 0x1010096, 0x1010097, 0x1010098, 0x7f010024
        };
        public static final int TextAppearance_android_textColor = 3;
        public static final int TextAppearance_android_textSize = 0;
        public static final int TextAppearance_android_textStyle = 2;
        public static final int TextAppearance_android_typeface = 1;
        public static final int TextAppearance_textAllCaps = 4;
        public static final int Theme[] = {
            0x1010057, 0x10100ae, 0x7f01004d, 0x7f01004e, 0x7f01004f, 0x7f010050, 0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054, 
            0x7f010055, 0x7f010056, 0x7f010057, 0x7f010058, 0x7f010059, 0x7f01005a, 0x7f01005b, 0x7f01005c, 0x7f01005d, 0x7f01005e, 
            0x7f01005f, 0x7f010060, 0x7f010061, 0x7f010062, 0x7f010063, 0x7f010064, 0x7f010065, 0x7f010066, 0x7f010067, 0x7f010068, 
            0x7f010069, 0x7f01006a, 0x7f01006b, 0x7f01006c, 0x7f01006d, 0x7f01006e, 0x7f01006f, 0x7f010070, 0x7f010071, 0x7f010072, 
            0x7f010073, 0x7f010074, 0x7f010075, 0x7f010076, 0x7f010077, 0x7f010078, 0x7f010079, 0x7f01007a, 0x7f01007b, 0x7f01007c, 
            0x7f01007d, 0x7f01007e, 0x7f01007f, 0x7f010080, 0x7f010081, 0x7f010082, 0x7f010083, 0x7f010084, 0x7f010085, 0x7f010086, 
            0x7f010087, 0x7f010088, 0x7f010089, 0x7f01008a, 0x7f01008b, 0x7f01008c, 0x7f01008d, 0x7f01008e, 0x7f01008f, 0x7f010090, 
            0x7f010091, 0x7f010092, 0x7f010093, 0x7f010094, 0x7f010095, 0x7f010096, 0x7f010097, 0x7f010098, 0x7f010099, 0x7f01009a, 
            0x7f01009b, 0x7f01009c, 0x7f01009d, 0x7f01009e, 0x7f01009f, 0x7f0100a0, 0x7f0100a1, 0x7f0100a2, 0x7f0100a3, 0x7f0100a4, 
            0x7f0100a5, 0x7f0100a6, 0x7f0100a7, 0x7f0100a8, 0x7f0100a9, 0x7f0100aa, 0x7f0100ab, 0x7f0100ac, 0x7f0100ad, 0x7f0100ae, 
            0x7f0100af, 0x7f0100b0, 0x7f0100b1, 0x7f0100b2, 0x7f0100b3, 0x7f0100b4, 0x7f0100b5, 0x7f0100b6
        };
        public static final int Theme_actionBarDivider = 23;
        public static final int Theme_actionBarItemBackground = 24;
        public static final int Theme_actionBarPopupTheme = 17;
        public static final int Theme_actionBarSize = 22;
        public static final int Theme_actionBarSplitStyle = 19;
        public static final int Theme_actionBarStyle = 18;
        public static final int Theme_actionBarTabBarStyle = 13;
        public static final int Theme_actionBarTabStyle = 12;
        public static final int Theme_actionBarTabTextStyle = 14;
        public static final int Theme_actionBarTheme = 20;
        public static final int Theme_actionBarWidgetTheme = 21;
        public static final int Theme_actionButtonStyle = 49;
        public static final int Theme_actionDropDownStyle = 45;
        public static final int Theme_actionMenuTextAppearance = 25;
        public static final int Theme_actionMenuTextColor = 26;
        public static final int Theme_actionModeBackground = 29;
        public static final int Theme_actionModeCloseButtonStyle = 28;
        public static final int Theme_actionModeCloseDrawable = 31;
        public static final int Theme_actionModeCopyDrawable = 33;
        public static final int Theme_actionModeCutDrawable = 32;
        public static final int Theme_actionModeFindDrawable = 37;
        public static final int Theme_actionModePasteDrawable = 34;
        public static final int Theme_actionModePopupWindowStyle = 39;
        public static final int Theme_actionModeSelectAllDrawable = 35;
        public static final int Theme_actionModeShareDrawable = 36;
        public static final int Theme_actionModeSplitBackground = 30;
        public static final int Theme_actionModeStyle = 27;
        public static final int Theme_actionModeWebSearchDrawable = 38;
        public static final int Theme_actionOverflowButtonStyle = 15;
        public static final int Theme_actionOverflowMenuStyle = 16;
        public static final int Theme_activityChooserViewStyle = 57;
        public static final int Theme_alertDialogButtonGroupStyle = 91;
        public static final int Theme_alertDialogCenterButtons = 92;
        public static final int Theme_alertDialogStyle = 90;
        public static final int Theme_alertDialogTheme = 93;
        public static final int Theme_android_windowAnimationStyle = 1;
        public static final int Theme_android_windowIsFloating = 0;
        public static final int Theme_autoCompleteTextViewStyle = 98;
        public static final int Theme_borderlessButtonStyle = 54;
        public static final int Theme_buttonBarButtonStyle = 51;
        public static final int Theme_buttonBarNegativeButtonStyle = 96;
        public static final int Theme_buttonBarNeutralButtonStyle = 97;
        public static final int Theme_buttonBarPositiveButtonStyle = 95;
        public static final int Theme_buttonBarStyle = 50;
        public static final int Theme_buttonStyle = 99;
        public static final int Theme_buttonStyleSmall = 100;
        public static final int Theme_checkboxStyle = 101;
        public static final int Theme_checkedTextViewStyle = 102;
        public static final int Theme_colorAccent = 83;
        public static final int Theme_colorButtonNormal = 87;
        public static final int Theme_colorControlActivated = 85;
        public static final int Theme_colorControlHighlight = 86;
        public static final int Theme_colorControlNormal = 84;
        public static final int Theme_colorPrimary = 81;
        public static final int Theme_colorPrimaryDark = 82;
        public static final int Theme_colorSwitchThumbNormal = 88;
        public static final int Theme_controlBackground = 89;
        public static final int Theme_dialogPreferredPadding = 43;
        public static final int Theme_dialogTheme = 42;
        public static final int Theme_dividerHorizontal = 56;
        public static final int Theme_dividerVertical = 55;
        public static final int Theme_dropDownListViewStyle = 73;
        public static final int Theme_dropdownListPreferredItemHeight = 46;
        public static final int Theme_editTextBackground = 63;
        public static final int Theme_editTextColor = 62;
        public static final int Theme_editTextStyle = 103;
        public static final int Theme_homeAsUpIndicator = 48;
        public static final int Theme_listChoiceBackgroundIndicator = 80;
        public static final int Theme_listDividerAlertDialog = 44;
        public static final int Theme_listPopupWindowStyle = 74;
        public static final int Theme_listPreferredItemHeight = 68;
        public static final int Theme_listPreferredItemHeightLarge = 70;
        public static final int Theme_listPreferredItemHeightSmall = 69;
        public static final int Theme_listPreferredItemPaddingLeft = 71;
        public static final int Theme_listPreferredItemPaddingRight = 72;
        public static final int Theme_panelBackground = 77;
        public static final int Theme_panelMenuListTheme = 79;
        public static final int Theme_panelMenuListWidth = 78;
        public static final int Theme_popupMenuStyle = 60;
        public static final int Theme_popupWindowStyle = 61;
        public static final int Theme_radioButtonStyle = 104;
        public static final int Theme_ratingBarStyle = 105;
        public static final int Theme_searchViewStyle = 67;
        public static final int Theme_selectableItemBackground = 52;
        public static final int Theme_selectableItemBackgroundBorderless = 53;
        public static final int Theme_spinnerDropDownItemStyle = 47;
        public static final int Theme_spinnerStyle = 106;
        public static final int Theme_switchStyle = 107;
        public static final int Theme_textAppearanceLargePopupMenu = 40;
        public static final int Theme_textAppearanceListItem = 75;
        public static final int Theme_textAppearanceListItemSmall = 76;
        public static final int Theme_textAppearanceSearchResultSubtitle = 65;
        public static final int Theme_textAppearanceSearchResultTitle = 64;
        public static final int Theme_textAppearanceSmallPopupMenu = 41;
        public static final int Theme_textColorAlertDialogListItem = 94;
        public static final int Theme_textColorSearchUrl = 66;
        public static final int Theme_toolbarNavigationButtonStyle = 59;
        public static final int Theme_toolbarStyle = 58;
        public static final int Theme_windowActionBar = 2;
        public static final int Theme_windowActionBarOverlay = 4;
        public static final int Theme_windowActionModeOverlay = 5;
        public static final int Theme_windowFixedHeightMajor = 9;
        public static final int Theme_windowFixedHeightMinor = 7;
        public static final int Theme_windowFixedWidthMajor = 6;
        public static final int Theme_windowFixedWidthMinor = 8;
        public static final int Theme_windowMinWidthMajor = 10;
        public static final int Theme_windowMinWidthMinor = 11;
        public static final int Theme_windowNoTitle = 3;
        public static final int Toolbar[] = {
            0x10100af, 0x1010140, 0x7f010003, 0x7f010006, 0x7f01000a, 0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001b, 
            0x7f0100b7, 0x7f0100b8, 0x7f0100b9, 0x7f0100ba, 0x7f0100bb, 0x7f0100bc, 0x7f0100bd, 0x7f0100be, 0x7f0100bf, 0x7f0100c0, 
            0x7f0100c1, 0x7f0100c2, 0x7f0100c3, 0x7f0100c4, 0x7f0100c5
        };
        public static final int Toolbar_android_gravity = 0;
        public static final int Toolbar_android_minHeight = 1;
        public static final int Toolbar_collapseContentDescription = 19;
        public static final int Toolbar_collapseIcon = 18;
        public static final int Toolbar_contentInsetEnd = 6;
        public static final int Toolbar_contentInsetLeft = 7;
        public static final int Toolbar_contentInsetRight = 8;
        public static final int Toolbar_contentInsetStart = 5;
        public static final int Toolbar_logo = 4;
        public static final int Toolbar_logoDescription = 22;
        public static final int Toolbar_maxButtonHeight = 17;
        public static final int Toolbar_navigationContentDescription = 21;
        public static final int Toolbar_navigationIcon = 20;
        public static final int Toolbar_popupTheme = 9;
        public static final int Toolbar_subtitle = 3;
        public static final int Toolbar_subtitleTextAppearance = 11;
        public static final int Toolbar_subtitleTextColor = 24;
        public static final int Toolbar_title = 2;
        public static final int Toolbar_titleMarginBottom = 16;
        public static final int Toolbar_titleMarginEnd = 14;
        public static final int Toolbar_titleMarginStart = 13;
        public static final int Toolbar_titleMarginTop = 15;
        public static final int Toolbar_titleMargins = 12;
        public static final int Toolbar_titleTextAppearance = 10;
        public static final int Toolbar_titleTextColor = 23;
        public static final int View[] = {
            0x1010000, 0x10100da, 0x7f0100c6, 0x7f0100c7, 0x7f0100c8
        };
        public static final int ViewBackgroundHelper[] = {
            0x10100d4, 0x7f0100c9, 0x7f0100ca
        };
        public static final int ViewBackgroundHelper_android_background = 0;
        public static final int ViewBackgroundHelper_backgroundTint = 1;
        public static final int ViewBackgroundHelper_backgroundTintMode = 2;
        public static final int ViewStubCompat[] = {
            0x10100d0, 0x10100f2, 0x10100f3
        };
        public static final int ViewStubCompat_android_id = 0;
        public static final int ViewStubCompat_android_inflatedId = 2;
        public static final int ViewStubCompat_android_layout = 1;
        public static final int View_android_focusable = 1;
        public static final int View_android_theme = 0;
        public static final int View_paddingEnd = 3;
        public static final int View_paddingStart = 2;
        public static final int View_theme = 4;


        public styleable()
        {
        }
    }


    public R()
    {
    }
}
