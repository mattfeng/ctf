// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int ActionBar[] = {
        0x7f010001, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 
        0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 
        0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f01007b
    };
    public static final int ActionBarLayout[] = {
        0x10100b3
    };
    public static final int ActionBarLayout_android_layout_gravity = 0;
    public static final int ActionBar_background = 10;
    public static final int ActionBar_backgroundSplit = 12;
    public static final int ActionBar_backgroundStacked = 11;
    public static final int ActionBar_contentInsetEnd = 21;
    public static final int ActionBar_contentInsetLeft = 22;
    public static final int ActionBar_contentInsetRight = 23;
    public static final int ActionBar_contentInsetStart = 20;
    public static final int ActionBar_customNavigationLayout = 13;
    public static final int ActionBar_displayOptions = 3;
    public static final int ActionBar_divider = 9;
    public static final int ActionBar_elevation = 24;
    public static final int ActionBar_height = 0;
    public static final int ActionBar_hideOnContentScroll = 19;
    public static final int ActionBar_homeAsUpIndicator = 26;
    public static final int ActionBar_homeLayout = 14;
    public static final int ActionBar_icon = 7;
    public static final int ActionBar_indeterminateProgressStyle = 16;
    public static final int ActionBar_itemPadding = 18;
    public static final int ActionBar_logo = 8;
    public static final int ActionBar_navigationMode = 2;
    public static final int ActionBar_popupTheme = 25;
    public static final int ActionBar_progressBarPadding = 17;
    public static final int ActionBar_progressBarStyle = 15;
    public static final int ActionBar_subtitle = 4;
    public static final int ActionBar_subtitleTextStyle = 6;
    public static final int ActionBar_title = 1;
    public static final int ActionBar_titleTextStyle = 5;
    public static final int ActionMenuItemView[] = {
        0x101013f
    };
    public static final int ActionMenuItemView_android_minWidth = 0;
    public static final int ActionMenuView[] = new int[0];
    public static final int ActionMode[] = {
        0x7f010001, 0x7f010007, 0x7f010008, 0x7f01000c, 0x7f01000e, 0x7f01001c
    };
    public static final int ActionMode_background = 3;
    public static final int ActionMode_backgroundSplit = 4;
    public static final int ActionMode_closeItemLayout = 5;
    public static final int ActionMode_height = 0;
    public static final int ActionMode_subtitleTextStyle = 2;
    public static final int ActionMode_titleTextStyle = 1;
    public static final int ActivityChooserView[] = {
        0x7f01001d, 0x7f01001e
    };
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
    public static final int ActivityChooserView_initialActivityCount = 0;
    public static final int AlertDialog[] = {
        0x10100f2, 0x7f01001f, 0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023
    };
    public static final int AlertDialog_android_layout = 0;
    public static final int AlertDialog_buttonPanelSideLayout = 1;
    public static final int AlertDialog_listItemLayout = 5;
    public static final int AlertDialog_listLayout = 2;
    public static final int AlertDialog_multiChoiceItemLayout = 3;
    public static final int AlertDialog_singleChoiceItemLayout = 4;
    public static final int AppCompatTextView[] = {
        0x1010034, 0x7f010024
    };
    public static final int AppCompatTextView_android_textAppearance = 0;
    public static final int AppCompatTextView_textAllCaps = 1;
    public static final int CompoundButton[] = {
        0x1010107, 0x7f010025, 0x7f010026
    };
    public static final int CompoundButton_android_button = 0;
    public static final int CompoundButton_buttonTint = 1;
    public static final int CompoundButton_buttonTintMode = 2;
    public static final int DrawerArrowToggle[] = {
        0x7f010027, 0x7f010028, 0x7f010029, 0x7f01002a, 0x7f01002b, 0x7f01002c, 0x7f01002d, 0x7f01002e
    };
    public static final int DrawerArrowToggle_arrowHeadLength = 4;
    public static final int DrawerArrowToggle_arrowShaftLength = 5;
    public static final int DrawerArrowToggle_barLength = 6;
    public static final int DrawerArrowToggle_color = 0;
    public static final int DrawerArrowToggle_drawableSize = 2;
    public static final int DrawerArrowToggle_gapBetweenBars = 3;
    public static final int DrawerArrowToggle_spinBars = 1;
    public static final int DrawerArrowToggle_thickness = 7;
    public static final int LinearLayoutCompat[] = {
        0x10100af, 0x10100c4, 0x1010126, 0x1010127, 0x1010128, 0x7f01000b, 0x7f01002f, 0x7f010030, 0x7f010031
    };
    public static final int LinearLayoutCompat_Layout[] = {
        0x10100b3, 0x10100f4, 0x10100f5, 0x1010181
    };
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    public static final int LinearLayoutCompat_android_gravity = 0;
    public static final int LinearLayoutCompat_android_orientation = 1;
    public static final int LinearLayoutCompat_android_weightSum = 4;
    public static final int LinearLayoutCompat_divider = 5;
    public static final int LinearLayoutCompat_dividerPadding = 8;
    public static final int LinearLayoutCompat_measureWithLargestChild = 6;
    public static final int LinearLayoutCompat_showDividers = 7;
    public static final int ListPopupWindow[] = {
        0x10102ac, 0x10102ad
    };
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    public static final int MenuGroup[] = {
        0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
    };
    public static final int MenuGroup_android_checkableBehavior = 5;
    public static final int MenuGroup_android_enabled = 0;
    public static final int MenuGroup_android_id = 1;
    public static final int MenuGroup_android_menuCategory = 3;
    public static final int MenuGroup_android_orderInCategory = 4;
    public static final int MenuGroup_android_visible = 2;
    public static final int MenuItem[] = {
        0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
        0x10101e4, 0x10101e5, 0x101026f, 0x7f010032, 0x7f010033, 0x7f010034, 0x7f010035
    };
    public static final int MenuItem_actionLayout = 14;
    public static final int MenuItem_actionProviderClass = 16;
    public static final int MenuItem_actionViewClass = 15;
    public static final int MenuItem_android_alphabeticShortcut = 9;
    public static final int MenuItem_android_checkable = 11;
    public static final int MenuItem_android_checked = 3;
    public static final int MenuItem_android_enabled = 1;
    public static final int MenuItem_android_icon = 0;
    public static final int MenuItem_android_id = 2;
    public static final int MenuItem_android_menuCategory = 5;
    public static final int MenuItem_android_numericShortcut = 10;
    public static final int MenuItem_android_onClick = 12;
    public static final int MenuItem_android_orderInCategory = 6;
    public static final int MenuItem_android_title = 7;
    public static final int MenuItem_android_titleCondensed = 8;
    public static final int MenuItem_android_visible = 4;
    public static final int MenuItem_showAsAction = 13;
    public static final int MenuView[] = {
        0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x7f010036
    };
    public static final int MenuView_android_headerBackground = 4;
    public static final int MenuView_android_horizontalDivider = 2;
    public static final int MenuView_android_itemBackground = 5;
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    public static final int MenuView_android_itemTextAppearance = 1;
    public static final int MenuView_android_verticalDivider = 3;
    public static final int MenuView_android_windowAnimationStyle = 0;
    public static final int MenuView_preserveIconSpacing = 7;
    public static final int PopupWindow[] = {
        0x1010176, 0x7f010037
    };
    public static final int PopupWindowBackgroundState[] = {
        0x7f010038
    };
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    public static final int PopupWindow_android_popupBackground = 0;
    public static final int PopupWindow_overlapAnchor = 1;
    public static final int SearchView[] = {
        0x10100da, 0x101011f, 0x1010220, 0x1010264, 0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c, 0x7f01003d, 0x7f01003e, 
        0x7f01003f, 0x7f010040, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045
    };
    public static final int SearchView_android_focusable = 0;
    public static final int SearchView_android_imeOptions = 3;
    public static final int SearchView_android_inputType = 2;
    public static final int SearchView_android_maxWidth = 1;
    public static final int SearchView_closeIcon = 8;
    public static final int SearchView_commitIcon = 13;
    public static final int SearchView_defaultQueryHint = 7;
    public static final int SearchView_goIcon = 9;
    public static final int SearchView_iconifiedByDefault = 5;
    public static final int SearchView_layout = 4;
    public static final int SearchView_queryBackground = 15;
    public static final int SearchView_queryHint = 6;
    public static final int SearchView_searchHintIcon = 11;
    public static final int SearchView_searchIcon = 10;
    public static final int SearchView_submitBackground = 16;
    public static final int SearchView_suggestionRowLayout = 14;
    public static final int SearchView_voiceIcon = 12;
    public static final int Spinner[] = {
        0x1010176, 0x101017b, 0x1010262, 0x7f01001b
    };
    public static final int Spinner_android_dropDownWidth = 2;
    public static final int Spinner_android_popupBackground = 0;
    public static final int Spinner_android_prompt = 1;
    public static final int Spinner_popupTheme = 3;
    public static final int SwitchCompat[] = {
        0x1010124, 0x1010125, 0x1010142, 0x7f010046, 0x7f010047, 0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c
    };
    public static final int SwitchCompat_android_textOff = 1;
    public static final int SwitchCompat_android_textOn = 0;
    public static final int SwitchCompat_android_thumb = 2;
    public static final int SwitchCompat_showText = 9;
    public static final int SwitchCompat_splitTrack = 8;
    public static final int SwitchCompat_switchMinWidth = 6;
    public static final int SwitchCompat_switchPadding = 7;
    public static final int SwitchCompat_switchTextAppearance = 5;
    public static final int SwitchCompat_thumbTextPadding = 4;
    public static final int SwitchCompat_track = 3;
    public static final int TextAppearance[] = {
        0x1010095, 0x1010096, 0x1010097, 0x1010098, 0x7f010024
    };
    public static final int TextAppearance_android_textColor = 3;
    public static final int TextAppearance_android_textSize = 0;
    public static final int TextAppearance_android_textStyle = 2;
    public static final int TextAppearance_android_typeface = 1;
    public static final int TextAppearance_textAllCaps = 4;
    public static final int Theme[] = {
        0x1010057, 0x10100ae, 0x7f01004d, 0x7f01004e, 0x7f01004f, 0x7f010050, 0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054, 
        0x7f010055, 0x7f010056, 0x7f010057, 0x7f010058, 0x7f010059, 0x7f01005a, 0x7f01005b, 0x7f01005c, 0x7f01005d, 0x7f01005e, 
        0x7f01005f, 0x7f010060, 0x7f010061, 0x7f010062, 0x7f010063, 0x7f010064, 0x7f010065, 0x7f010066, 0x7f010067, 0x7f010068, 
        0x7f010069, 0x7f01006a, 0x7f01006b, 0x7f01006c, 0x7f01006d, 0x7f01006e, 0x7f01006f, 0x7f010070, 0x7f010071, 0x7f010072, 
        0x7f010073, 0x7f010074, 0x7f010075, 0x7f010076, 0x7f010077, 0x7f010078, 0x7f010079, 0x7f01007a, 0x7f01007b, 0x7f01007c, 
        0x7f01007d, 0x7f01007e, 0x7f01007f, 0x7f010080, 0x7f010081, 0x7f010082, 0x7f010083, 0x7f010084, 0x7f010085, 0x7f010086, 
        0x7f010087, 0x7f010088, 0x7f010089, 0x7f01008a, 0x7f01008b, 0x7f01008c, 0x7f01008d, 0x7f01008e, 0x7f01008f, 0x7f010090, 
        0x7f010091, 0x7f010092, 0x7f010093, 0x7f010094, 0x7f010095, 0x7f010096, 0x7f010097, 0x7f010098, 0x7f010099, 0x7f01009a, 
        0x7f01009b, 0x7f01009c, 0x7f01009d, 0x7f01009e, 0x7f01009f, 0x7f0100a0, 0x7f0100a1, 0x7f0100a2, 0x7f0100a3, 0x7f0100a4, 
        0x7f0100a5, 0x7f0100a6, 0x7f0100a7, 0x7f0100a8, 0x7f0100a9, 0x7f0100aa, 0x7f0100ab, 0x7f0100ac, 0x7f0100ad, 0x7f0100ae, 
        0x7f0100af, 0x7f0100b0, 0x7f0100b1, 0x7f0100b2, 0x7f0100b3, 0x7f0100b4, 0x7f0100b5, 0x7f0100b6
    };
    public static final int Theme_actionBarDivider = 23;
    public static final int Theme_actionBarItemBackground = 24;
    public static final int Theme_actionBarPopupTheme = 17;
    public static final int Theme_actionBarSize = 22;
    public static final int Theme_actionBarSplitStyle = 19;
    public static final int Theme_actionBarStyle = 18;
    public static final int Theme_actionBarTabBarStyle = 13;
    public static final int Theme_actionBarTabStyle = 12;
    public static final int Theme_actionBarTabTextStyle = 14;
    public static final int Theme_actionBarTheme = 20;
    public static final int Theme_actionBarWidgetTheme = 21;
    public static final int Theme_actionButtonStyle = 49;
    public static final int Theme_actionDropDownStyle = 45;
    public static final int Theme_actionMenuTextAppearance = 25;
    public static final int Theme_actionMenuTextColor = 26;
    public static final int Theme_actionModeBackground = 29;
    public static final int Theme_actionModeCloseButtonStyle = 28;
    public static final int Theme_actionModeCloseDrawable = 31;
    public static final int Theme_actionModeCopyDrawable = 33;
    public static final int Theme_actionModeCutDrawable = 32;
    public static final int Theme_actionModeFindDrawable = 37;
    public static final int Theme_actionModePasteDrawable = 34;
    public static final int Theme_actionModePopupWindowStyle = 39;
    public static final int Theme_actionModeSelectAllDrawable = 35;
    public static final int Theme_actionModeShareDrawable = 36;
    public static final int Theme_actionModeSplitBackground = 30;
    public static final int Theme_actionModeStyle = 27;
    public static final int Theme_actionModeWebSearchDrawable = 38;
    public static final int Theme_actionOverflowButtonStyle = 15;
    public static final int Theme_actionOverflowMenuStyle = 16;
    public static final int Theme_activityChooserViewStyle = 57;
    public static final int Theme_alertDialogButtonGroupStyle = 91;
    public static final int Theme_alertDialogCenterButtons = 92;
    public static final int Theme_alertDialogStyle = 90;
    public static final int Theme_alertDialogTheme = 93;
    public static final int Theme_android_windowAnimationStyle = 1;
    public static final int Theme_android_windowIsFloating = 0;
    public static final int Theme_autoCompleteTextViewStyle = 98;
    public static final int Theme_borderlessButtonStyle = 54;
    public static final int Theme_buttonBarButtonStyle = 51;
    public static final int Theme_buttonBarNegativeButtonStyle = 96;
    public static final int Theme_buttonBarNeutralButtonStyle = 97;
    public static final int Theme_buttonBarPositiveButtonStyle = 95;
    public static final int Theme_buttonBarStyle = 50;
    public static final int Theme_buttonStyle = 99;
    public static final int Theme_buttonStyleSmall = 100;
    public static final int Theme_checkboxStyle = 101;
    public static final int Theme_checkedTextViewStyle = 102;
    public static final int Theme_colorAccent = 83;
    public static final int Theme_colorButtonNormal = 87;
    public static final int Theme_colorControlActivated = 85;
    public static final int Theme_colorControlHighlight = 86;
    public static final int Theme_colorControlNormal = 84;
    public static final int Theme_colorPrimary = 81;
    public static final int Theme_colorPrimaryDark = 82;
    public static final int Theme_colorSwitchThumbNormal = 88;
    public static final int Theme_controlBackground = 89;
    public static final int Theme_dialogPreferredPadding = 43;
    public static final int Theme_dialogTheme = 42;
    public static final int Theme_dividerHorizontal = 56;
    public static final int Theme_dividerVertical = 55;
    public static final int Theme_dropDownListViewStyle = 73;
    public static final int Theme_dropdownListPreferredItemHeight = 46;
    public static final int Theme_editTextBackground = 63;
    public static final int Theme_editTextColor = 62;
    public static final int Theme_editTextStyle = 103;
    public static final int Theme_homeAsUpIndicator = 48;
    public static final int Theme_listChoiceBackgroundIndicator = 80;
    public static final int Theme_listDividerAlertDialog = 44;
    public static final int Theme_listPopupWindowStyle = 74;
    public static final int Theme_listPreferredItemHeight = 68;
    public static final int Theme_listPreferredItemHeightLarge = 70;
    public static final int Theme_listPreferredItemHeightSmall = 69;
    public static final int Theme_listPreferredItemPaddingLeft = 71;
    public static final int Theme_listPreferredItemPaddingRight = 72;
    public static final int Theme_panelBackground = 77;
    public static final int Theme_panelMenuListTheme = 79;
    public static final int Theme_panelMenuListWidth = 78;
    public static final int Theme_popupMenuStyle = 60;
    public static final int Theme_popupWindowStyle = 61;
    public static final int Theme_radioButtonStyle = 104;
    public static final int Theme_ratingBarStyle = 105;
    public static final int Theme_searchViewStyle = 67;
    public static final int Theme_selectableItemBackground = 52;
    public static final int Theme_selectableItemBackgroundBorderless = 53;
    public static final int Theme_spinnerDropDownItemStyle = 47;
    public static final int Theme_spinnerStyle = 106;
    public static final int Theme_switchStyle = 107;
    public static final int Theme_textAppearanceLargePopupMenu = 40;
    public static final int Theme_textAppearanceListItem = 75;
    public static final int Theme_textAppearanceListItemSmall = 76;
    public static final int Theme_textAppearanceSearchResultSubtitle = 65;
    public static final int Theme_textAppearanceSearchResultTitle = 64;
    public static final int Theme_textAppearanceSmallPopupMenu = 41;
    public static final int Theme_textColorAlertDialogListItem = 94;
    public static final int Theme_textColorSearchUrl = 66;
    public static final int Theme_toolbarNavigationButtonStyle = 59;
    public static final int Theme_toolbarStyle = 58;
    public static final int Theme_windowActionBar = 2;
    public static final int Theme_windowActionBarOverlay = 4;
    public static final int Theme_windowActionModeOverlay = 5;
    public static final int Theme_windowFixedHeightMajor = 9;
    public static final int Theme_windowFixedHeightMinor = 7;
    public static final int Theme_windowFixedWidthMajor = 6;
    public static final int Theme_windowFixedWidthMinor = 8;
    public static final int Theme_windowMinWidthMajor = 10;
    public static final int Theme_windowMinWidthMinor = 11;
    public static final int Theme_windowNoTitle = 3;
    public static final int Toolbar[] = {
        0x10100af, 0x1010140, 0x7f010003, 0x7f010006, 0x7f01000a, 0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001b, 
        0x7f0100b7, 0x7f0100b8, 0x7f0100b9, 0x7f0100ba, 0x7f0100bb, 0x7f0100bc, 0x7f0100bd, 0x7f0100be, 0x7f0100bf, 0x7f0100c0, 
        0x7f0100c1, 0x7f0100c2, 0x7f0100c3, 0x7f0100c4, 0x7f0100c5
    };
    public static final int Toolbar_android_gravity = 0;
    public static final int Toolbar_android_minHeight = 1;
    public static final int Toolbar_collapseContentDescription = 19;
    public static final int Toolbar_collapseIcon = 18;
    public static final int Toolbar_contentInsetEnd = 6;
    public static final int Toolbar_contentInsetLeft = 7;
    public static final int Toolbar_contentInsetRight = 8;
    public static final int Toolbar_contentInsetStart = 5;
    public static final int Toolbar_logo = 4;
    public static final int Toolbar_logoDescription = 22;
    public static final int Toolbar_maxButtonHeight = 17;
    public static final int Toolbar_navigationContentDescription = 21;
    public static final int Toolbar_navigationIcon = 20;
    public static final int Toolbar_popupTheme = 9;
    public static final int Toolbar_subtitle = 3;
    public static final int Toolbar_subtitleTextAppearance = 11;
    public static final int Toolbar_subtitleTextColor = 24;
    public static final int Toolbar_title = 2;
    public static final int Toolbar_titleMarginBottom = 16;
    public static final int Toolbar_titleMarginEnd = 14;
    public static final int Toolbar_titleMarginStart = 13;
    public static final int Toolbar_titleMarginTop = 15;
    public static final int Toolbar_titleMargins = 12;
    public static final int Toolbar_titleTextAppearance = 10;
    public static final int Toolbar_titleTextColor = 23;
    public static final int View[] = {
        0x1010000, 0x10100da, 0x7f0100c6, 0x7f0100c7, 0x7f0100c8
    };
    public static final int ViewBackgroundHelper[] = {
        0x10100d4, 0x7f0100c9, 0x7f0100ca
    };
    public static final int ViewBackgroundHelper_android_background = 0;
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    public static final int ViewStubCompat[] = {
        0x10100d0, 0x10100f2, 0x10100f3
    };
    public static final int ViewStubCompat_android_id = 0;
    public static final int ViewStubCompat_android_inflatedId = 2;
    public static final int ViewStubCompat_android_layout = 1;
    public static final int View_android_focusable = 1;
    public static final int View_android_theme = 0;
    public static final int View_paddingEnd = 3;
    public static final int View_paddingStart = 2;
    public static final int View_theme = 4;


    public ()
    {
    }
}
