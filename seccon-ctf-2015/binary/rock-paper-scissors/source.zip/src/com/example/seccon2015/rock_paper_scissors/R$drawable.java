// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int abc_ab_share_pack_mtrl_alpha = 0x7f020000;
    public static final int abc_action_bar_item_background_material = 0x7f020001;
    public static final int abc_btn_borderless_material = 0x7f020002;
    public static final int abc_btn_check_material = 0x7f020003;
    public static final int abc_btn_check_to_on_mtrl_000 = 0x7f020004;
    public static final int abc_btn_check_to_on_mtrl_015 = 0x7f020005;
    public static final int abc_btn_colored_material = 0x7f020006;
    public static final int abc_btn_default_mtrl_shape = 0x7f020007;
    public static final int abc_btn_radio_material = 0x7f020008;
    public static final int abc_btn_radio_to_on_mtrl_000 = 0x7f020009;
    public static final int abc_btn_radio_to_on_mtrl_015 = 0x7f02000a;
    public static final int abc_btn_rating_star_off_mtrl_alpha = 0x7f02000b;
    public static final int abc_btn_rating_star_on_mtrl_alpha = 0x7f02000c;
    public static final int abc_btn_switch_to_on_mtrl_00001 = 0x7f02000d;
    public static final int abc_btn_switch_to_on_mtrl_00012 = 0x7f02000e;
    public static final int abc_cab_background_internal_bg = 0x7f02000f;
    public static final int abc_cab_background_top_material = 0x7f020010;
    public static final int abc_cab_background_top_mtrl_alpha = 0x7f020011;
    public static final int abc_control_background_material = 0x7f020012;
    public static final int abc_dialog_material_background_dark = 0x7f020013;
    public static final int abc_dialog_material_background_light = 0x7f020014;
    public static final int abc_edit_text_material = 0x7f020015;
    public static final int abc_ic_ab_back_mtrl_am_alpha = 0x7f020016;
    public static final int abc_ic_clear_mtrl_alpha = 0x7f020017;
    public static final int abc_ic_commit_search_api_mtrl_alpha = 0x7f020018;
    public static final int abc_ic_go_search_api_mtrl_alpha = 0x7f020019;
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f02001a;
    public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f02001b;
    public static final int abc_ic_menu_moreoverflow_mtrl_alpha = 0x7f02001c;
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f02001d;
    public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f02001e;
    public static final int abc_ic_menu_share_mtrl_alpha = 0x7f02001f;
    public static final int abc_ic_search_api_mtrl_alpha = 0x7f020020;
    public static final int abc_ic_voice_search_api_mtrl_alpha = 0x7f020021;
    public static final int abc_item_background_holo_dark = 0x7f020022;
    public static final int abc_item_background_holo_light = 0x7f020023;
    public static final int abc_list_divider_mtrl_alpha = 0x7f020024;
    public static final int abc_list_focused_holo = 0x7f020025;
    public static final int abc_list_longpressed_holo = 0x7f020026;
    public static final int abc_list_pressed_holo_dark = 0x7f020027;
    public static final int abc_list_pressed_holo_light = 0x7f020028;
    public static final int abc_list_selector_background_transition_holo_dark = 0x7f020029;
    public static final int abc_list_selector_background_transition_holo_light = 0x7f02002a;
    public static final int abc_list_selector_disabled_holo_dark = 0x7f02002b;
    public static final int abc_list_selector_disabled_holo_light = 0x7f02002c;
    public static final int abc_list_selector_holo_dark = 0x7f02002d;
    public static final int abc_list_selector_holo_light = 0x7f02002e;
    public static final int abc_menu_hardkey_panel_mtrl_mult = 0x7f02002f;
    public static final int abc_popup_background_mtrl_mult = 0x7f020030;
    public static final int abc_ratingbar_full_material = 0x7f020031;
    public static final int abc_spinner_mtrl_am_alpha = 0x7f020032;
    public static final int abc_spinner_textfield_background_material = 0x7f020033;
    public static final int abc_switch_thumb_material = 0x7f020034;
    public static final int abc_switch_track_mtrl_alpha = 0x7f020035;
    public static final int abc_tab_indicator_material = 0x7f020036;
    public static final int abc_tab_indicator_mtrl_alpha = 0x7f020037;
    public static final int abc_text_cursor_material = 0x7f020038;
    public static final int abc_textfield_activated_mtrl_alpha = 0x7f020039;
    public static final int abc_textfield_default_mtrl_alpha = 0x7f02003a;
    public static final int abc_textfield_search_activated_mtrl_alpha = 0x7f02003b;
    public static final int abc_textfield_search_default_mtrl_alpha = 0x7f02003c;
    public static final int abc_textfield_search_material = 0x7f02003d;
    public static final int notification_template_icon_bg = 0x7f02003e;

    public ()
    {
    }
}
