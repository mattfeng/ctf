// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int abc_background_cache_hint_selector_material_dark = 0x7f0b003d;
    public static final int abc_background_cache_hint_selector_material_light = 0x7f0b003e;
    public static final int abc_color_highlight_material = 0x7f0b003f;
    public static final int abc_input_method_navigation_guard = 0x7f0b0000;
    public static final int abc_primary_text_disable_only_material_dark = 0x7f0b0040;
    public static final int abc_primary_text_disable_only_material_light = 0x7f0b0041;
    public static final int abc_primary_text_material_dark = 0x7f0b0042;
    public static final int abc_primary_text_material_light = 0x7f0b0043;
    public static final int abc_search_url_text = 0x7f0b0044;
    public static final int abc_search_url_text_normal = 0x7f0b0001;
    public static final int abc_search_url_text_pressed = 0x7f0b0002;
    public static final int abc_search_url_text_selected = 0x7f0b0003;
    public static final int abc_secondary_text_material_dark = 0x7f0b0045;
    public static final int abc_secondary_text_material_light = 0x7f0b0046;
    public static final int accent_material_dark = 0x7f0b0004;
    public static final int accent_material_light = 0x7f0b0005;
    public static final int background_floating_material_dark = 0x7f0b0006;
    public static final int background_floating_material_light = 0x7f0b0007;
    public static final int background_material_dark = 0x7f0b0008;
    public static final int background_material_light = 0x7f0b0009;
    public static final int bright_foreground_disabled_material_dark = 0x7f0b000a;
    public static final int bright_foreground_disabled_material_light = 0x7f0b000b;
    public static final int bright_foreground_inverse_material_dark = 0x7f0b000c;
    public static final int bright_foreground_inverse_material_light = 0x7f0b000d;
    public static final int bright_foreground_material_dark = 0x7f0b000e;
    public static final int bright_foreground_material_light = 0x7f0b000f;
    public static final int button_material_dark = 0x7f0b0010;
    public static final int button_material_light = 0x7f0b0011;
    public static final int colorAccent = 0x7f0b0012;
    public static final int colorPrimary = 0x7f0b0013;
    public static final int colorPrimaryDark = 0x7f0b0014;
    public static final int dim_foreground_disabled_material_dark = 0x7f0b0015;
    public static final int dim_foreground_disabled_material_light = 0x7f0b0016;
    public static final int dim_foreground_material_dark = 0x7f0b0017;
    public static final int dim_foreground_material_light = 0x7f0b0018;
    public static final int foreground_material_dark = 0x7f0b0019;
    public static final int foreground_material_light = 0x7f0b001a;
    public static final int highlighted_text_material_dark = 0x7f0b001b;
    public static final int highlighted_text_material_light = 0x7f0b001c;
    public static final int hint_foreground_material_dark = 0x7f0b001d;
    public static final int hint_foreground_material_light = 0x7f0b001e;
    public static final int material_blue_grey_800 = 0x7f0b001f;
    public static final int material_blue_grey_900 = 0x7f0b0020;
    public static final int material_blue_grey_950 = 0x7f0b0021;
    public static final int material_deep_teal_200 = 0x7f0b0022;
    public static final int material_deep_teal_500 = 0x7f0b0023;
    public static final int material_grey_100 = 0x7f0b0024;
    public static final int material_grey_300 = 0x7f0b0025;
    public static final int material_grey_50 = 0x7f0b0026;
    public static final int material_grey_600 = 0x7f0b0027;
    public static final int material_grey_800 = 0x7f0b0028;
    public static final int material_grey_850 = 0x7f0b0029;
    public static final int material_grey_900 = 0x7f0b002a;
    public static final int primary_dark_material_dark = 0x7f0b002b;
    public static final int primary_dark_material_light = 0x7f0b002c;
    public static final int primary_material_dark = 0x7f0b002d;
    public static final int primary_material_light = 0x7f0b002e;
    public static final int primary_text_default_material_dark = 0x7f0b002f;
    public static final int primary_text_default_material_light = 0x7f0b0030;
    public static final int primary_text_disabled_material_dark = 0x7f0b0031;
    public static final int primary_text_disabled_material_light = 0x7f0b0032;
    public static final int ripple_material_dark = 0x7f0b0033;
    public static final int ripple_material_light = 0x7f0b0034;
    public static final int secondary_text_default_material_dark = 0x7f0b0035;
    public static final int secondary_text_default_material_light = 0x7f0b0036;
    public static final int secondary_text_disabled_material_dark = 0x7f0b0037;
    public static final int secondary_text_disabled_material_light = 0x7f0b0038;
    public static final int switch_thumb_disabled_material_dark = 0x7f0b0039;
    public static final int switch_thumb_disabled_material_light = 0x7f0b003a;
    public static final int switch_thumb_material_dark = 0x7f0b0047;
    public static final int switch_thumb_material_light = 0x7f0b0048;
    public static final int switch_thumb_normal_material_dark = 0x7f0b003b;
    public static final int switch_thumb_normal_material_light = 0x7f0b003c;

    public ()
    {
    }
}
