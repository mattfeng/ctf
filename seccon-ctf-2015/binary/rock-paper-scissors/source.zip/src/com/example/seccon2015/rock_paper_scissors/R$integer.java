// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int abc_config_activityDefaultDur = 0x7f0a0001;
    public static final int abc_config_activityShortDur = 0x7f0a0002;
    public static final int abc_max_action_buttons = 0x7f0a0000;
    public static final int cancel_button_image_alpha = 0x7f0a0003;
    public static final int status_bar_notification_info_maxnum = 0x7f0a0004;

    public ()
    {
    }
}
