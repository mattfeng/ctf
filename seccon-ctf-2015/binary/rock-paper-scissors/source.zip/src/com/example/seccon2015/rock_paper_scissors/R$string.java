// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class _cls9
{

    public static final int abc_action_bar_home_description = 0x7f060000;
    public static final int abc_action_bar_home_description_format = 0x7f060001;
    public static final int abc_action_bar_home_subtitle_description_format = 0x7f060002;
    public static final int abc_action_bar_up_description = 0x7f060003;
    public static final int abc_action_menu_overflow_description = 0x7f060004;
    public static final int abc_action_mode_done = 0x7f060005;
    public static final int abc_activity_chooser_view_see_all = 0x7f060006;
    public static final int abc_activitychooserview_choose_application = 0x7f060007;
    public static final int abc_search_hint = 0x7f060008;
    public static final int abc_searchview_description_clear = 0x7f060009;
    public static final int abc_searchview_description_query = 0x7f06000a;
    public static final int abc_searchview_description_search = 0x7f06000b;
    public static final int abc_searchview_description_submit = 0x7f06000c;
    public static final int abc_searchview_description_voice = 0x7f06000d;
    public static final int abc_shareactionprovider_share_with = 0x7f06000e;
    public static final int abc_shareactionprovider_share_with_application = 0x7f06000f;
    public static final int abc_toolbar_collapse_description = 0x7f060010;
    public static final int app_name = 0x7f060012;
    public static final int app_text = 0x7f060013;
    public static final int status_bar_notification_info_overflow = 0x7f060011;

    public _cls9()
    {
    }
}
