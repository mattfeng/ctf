// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int action0 = 0x7f0c0053;
    public static final int action_bar = 0x7f0c003e;
    public static final int action_bar_activity_content = 0x7f0c0000;
    public static final int action_bar_container = 0x7f0c003d;
    public static final int action_bar_root = 0x7f0c0039;
    public static final int action_bar_spinner = 0x7f0c0001;
    public static final int action_bar_subtitle = 0x7f0c0022;
    public static final int action_bar_title = 0x7f0c0021;
    public static final int action_context_bar = 0x7f0c003f;
    public static final int action_divider = 0x7f0c0057;
    public static final int action_menu_divider = 0x7f0c0002;
    public static final int action_menu_presenter = 0x7f0c0003;
    public static final int action_mode_bar = 0x7f0c003b;
    public static final int action_mode_bar_stub = 0x7f0c003a;
    public static final int action_mode_close_button = 0x7f0c0023;
    public static final int activity_chooser_view_content = 0x7f0c0024;
    public static final int alertTitle = 0x7f0c002e;
    public static final int always = 0x7f0c001b;
    public static final int beginning = 0x7f0c0018;
    public static final int button = 0x7f0c004d;
    public static final int button3 = 0x7f0c004f;
    public static final int buttonPanel = 0x7f0c0034;
    public static final int buttonR = 0x7f0c004e;
    public static final int cancel_action = 0x7f0c0054;
    public static final int checkbox = 0x7f0c0036;
    public static final int chronometer = 0x7f0c005a;
    public static final int collapseActionView = 0x7f0c001c;
    public static final int contentPanel = 0x7f0c002f;
    public static final int custom = 0x7f0c0033;
    public static final int customPanel = 0x7f0c0032;
    public static final int decor_content_parent = 0x7f0c003c;
    public static final int default_activity_button = 0x7f0c0027;
    public static final int disableHome = 0x7f0c000c;
    public static final int edit_query = 0x7f0c0040;
    public static final int end = 0x7f0c0019;
    public static final int end_padder = 0x7f0c005f;
    public static final int expand_activities_button = 0x7f0c0025;
    public static final int expanded_menu = 0x7f0c0035;
    public static final int home = 0x7f0c0004;
    public static final int homeAsUp = 0x7f0c000d;
    public static final int icon = 0x7f0c0029;
    public static final int ifRoom = 0x7f0c001d;
    public static final int image = 0x7f0c0026;
    public static final int info = 0x7f0c005e;
    public static final int line1 = 0x7f0c0058;
    public static final int line3 = 0x7f0c005c;
    public static final int listMode = 0x7f0c0009;
    public static final int list_item = 0x7f0c0028;
    public static final int media_actions = 0x7f0c0056;
    public static final int middle = 0x7f0c001a;
    public static final int multiply = 0x7f0c0013;
    public static final int never = 0x7f0c001e;
    public static final int none = 0x7f0c000e;
    public static final int normal = 0x7f0c000a;
    public static final int parentPanel = 0x7f0c002b;
    public static final int progress_circular = 0x7f0c0005;
    public static final int progress_horizontal = 0x7f0c0006;
    public static final int radio = 0x7f0c0038;
    public static final int screen = 0x7f0c0014;
    public static final int scrollView = 0x7f0c0030;
    public static final int search_badge = 0x7f0c0042;
    public static final int search_bar = 0x7f0c0041;
    public static final int search_button = 0x7f0c0043;
    public static final int search_close_btn = 0x7f0c0048;
    public static final int search_edit_frame = 0x7f0c0044;
    public static final int search_go_btn = 0x7f0c004a;
    public static final int search_mag_icon = 0x7f0c0045;
    public static final int search_plate = 0x7f0c0046;
    public static final int search_src_text = 0x7f0c0047;
    public static final int search_voice_btn = 0x7f0c004b;
    public static final int select_dialog_listview = 0x7f0c004c;
    public static final int shortcut = 0x7f0c0037;
    public static final int showCustom = 0x7f0c000f;
    public static final int showHome = 0x7f0c0010;
    public static final int showTitle = 0x7f0c0011;
    public static final int split_action_bar = 0x7f0c0007;
    public static final int src_atop = 0x7f0c0015;
    public static final int src_in = 0x7f0c0016;
    public static final int src_over = 0x7f0c0017;
    public static final int status_bar_latest_event_content = 0x7f0c0055;
    public static final int submit_area = 0x7f0c0049;
    public static final int tabMode = 0x7f0c000b;
    public static final int text = 0x7f0c005d;
    public static final int text2 = 0x7f0c005b;
    public static final int textSpacerNoButtons = 0x7f0c0031;
    public static final int textView = 0x7f0c0050;
    public static final int textView2 = 0x7f0c0051;
    public static final int textView3 = 0x7f0c0052;
    public static final int time = 0x7f0c0059;
    public static final int title = 0x7f0c002a;
    public static final int title_template = 0x7f0c002d;
    public static final int topPanel = 0x7f0c002c;
    public static final int up = 0x7f0c0008;
    public static final int useLogo = 0x7f0c0012;
    public static final int withText = 0x7f0c001f;
    public static final int wrap_content = 0x7f0c0020;

    public ()
    {
    }
}
