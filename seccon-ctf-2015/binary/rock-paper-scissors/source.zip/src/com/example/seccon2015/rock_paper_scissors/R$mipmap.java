// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class _cls9
{

    public static final int ic_launcher = 0x7f030000;

    public _cls9()
    {
    }
}
