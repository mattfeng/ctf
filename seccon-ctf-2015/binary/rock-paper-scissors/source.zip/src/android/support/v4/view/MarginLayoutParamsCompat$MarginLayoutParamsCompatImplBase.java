// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;


// Referenced classes of package android.support.v4.view:
//            MarginLayoutParamsCompat

static class 
    implements 
{

    public int getLayoutDirection(android.view.atImplBase atimplbase)
    {
        return 0;
    }

    public int getMarginEnd(android.view.atImplBase atimplbase)
    {
        return atimplbase.atImplBase;
    }

    public int getMarginStart(android.view.atImplBase atimplbase)
    {
        return atimplbase.atImplBase;
    }

    public boolean isMarginRelative(android.view.atImplBase atimplbase)
    {
        return false;
    }

    public void resolveLayoutDirection(android.view.atImplBase atimplbase, int i)
    {
    }

    public void setLayoutDirection(android.view.atImplBase atimplbase, int i)
    {
    }

    public void setMarginEnd(android.view.atImplBase atimplbase, int i)
    {
        atimplbase.atImplBase = i;
    }

    public void setMarginStart(android.view.atImplBase atimplbase, int i)
    {
        atimplbase.atImplBase = i;
    }

    ()
    {
    }
}
