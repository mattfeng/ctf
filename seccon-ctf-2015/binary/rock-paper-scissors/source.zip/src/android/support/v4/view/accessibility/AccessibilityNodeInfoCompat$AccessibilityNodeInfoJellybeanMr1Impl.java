// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.view.View;

// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityNodeInfoCompat, AccessibilityNodeInfoCompatJellybeanMr1

static class  extends 
{

    public Object getLabelFor(Object obj)
    {
        return AccessibilityNodeInfoCompatJellybeanMr1.getLabelFor(obj);
    }

    public Object getLabeledBy(Object obj)
    {
        return AccessibilityNodeInfoCompatJellybeanMr1.getLabeledBy(obj);
    }

    public void setLabelFor(Object obj, View view)
    {
        AccessibilityNodeInfoCompatJellybeanMr1.setLabelFor(obj, view);
    }

    public void setLabelFor(Object obj, View view, int i)
    {
        AccessibilityNodeInfoCompatJellybeanMr1.setLabelFor(obj, view, i);
    }

    public void setLabeledBy(Object obj, View view)
    {
        AccessibilityNodeInfoCompatJellybeanMr1.setLabeledBy(obj, view);
    }

    public void setLabeledBy(Object obj, View view, int i)
    {
        AccessibilityNodeInfoCompatJellybeanMr1.setLabeledBy(obj, view, i);
    }

    ()
    {
    }
}
