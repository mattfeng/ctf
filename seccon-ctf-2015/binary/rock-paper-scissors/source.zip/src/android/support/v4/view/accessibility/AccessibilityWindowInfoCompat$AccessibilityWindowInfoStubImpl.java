// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.graphics.Rect;

// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityWindowInfoCompat

private static class <init>
    implements <init>
{

    public void getBoundsInScreen(Object obj, Rect rect)
    {
    }

    public Object getChild(Object obj, int i)
    {
        return null;
    }

    public int getChildCount(Object obj)
    {
        return 0;
    }

    public int getId(Object obj)
    {
        return -1;
    }

    public int getLayer(Object obj)
    {
        return -1;
    }

    public Object getParent(Object obj)
    {
        return null;
    }

    public Object getRoot(Object obj)
    {
        return null;
    }

    public int getType(Object obj)
    {
        return -1;
    }

    public boolean isAccessibilityFocused(Object obj)
    {
        return true;
    }

    public boolean isActive(Object obj)
    {
        return true;
    }

    public boolean isFocused(Object obj)
    {
        return true;
    }

    public Object obtain()
    {
        return null;
    }

    public Object obtain(Object obj)
    {
        return null;
    }

    public void recycle(Object obj)
    {
    }

    private i()
    {
    }

    i(i i)
    {
        this();
    }
}
