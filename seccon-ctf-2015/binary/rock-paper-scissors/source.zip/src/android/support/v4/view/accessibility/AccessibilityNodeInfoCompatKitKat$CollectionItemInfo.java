// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityNodeInfoCompatKitKat

static class 
{

    static int getColumnIndex(Object obj)
    {
        return ((android.view.accessibility.onItemInfo)obj).ex();
    }

    static int getColumnSpan(Object obj)
    {
        return ((android.view.accessibility.ex)obj).n();
    }

    static int getRowIndex(Object obj)
    {
        return ((android.view.accessibility.n)obj).n();
    }

    static int getRowSpan(Object obj)
    {
        return ((android.view.accessibility.n)obj).n();
    }

    static boolean isHeading(Object obj)
    {
        return ((android.view.accessibility.n)obj).n();
    }

    ()
    {
    }
}
