// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityNodeInfoCompatKitKat

static class 
{

    static float getCurrent(Object obj)
    {
        return ((android.view.accessibility..RangeInfo)obj).RangeInfo();
    }

    static float getMax(Object obj)
    {
        return ((android.view.accessibility..RangeInfo)obj).RangeInfo();
    }

    static float getMin(Object obj)
    {
        return ((android.view.accessibility..RangeInfo)obj).RangeInfo();
    }

    static int getType(Object obj)
    {
        return ((android.view.accessibility..RangeInfo)obj).RangeInfo();
    }

    ()
    {
    }
}
